import React from 'react';
import { Text, View, FlatList, Image, TouchableOpacity,Picker, SafeAreaView, ScrollView,Modal,} from 'react-native';
import {
  Container,
  Header,
  Content,
  Left,
  Right,
  Body,
  Icon,
  ListItem,
  Thumbnail,
  Input,
  Footer,
} from 'native-base';
import styles from "./styles"
import firebase from '../pages/firebase.js';
import AsyncStorage from '@react-native-community/async-storage';
const db = firebase.firestore();
const data=[];
const datax=[];
const cartx=[];
const order=[];
const cat="Man cloths with today offer";
export default class App extends React.Component {
     constructor({route,navigation}){
const {Cid} =route.params;
    super();
    this.state = {
      navigation:navigation,
      Value:1,
      modalVisible: false,
      rok:[],
      Rdata:0,
      index:0,
      cart:0,
      address:"",
      name:"Address not found",
      mobile:"",
      Colony:"",
      pincode:"",
      home:'',
      City:'',
      Total:0,
      ItemN:0,
      TotalOld:0,
      Uid:"",
      aid:'',
      Cid:Cid,
      Status:1,
      lode:0,
    };
                      }
          componentDidMount() {
            this.getData();
               db.collection('track')
               .where('Uid', '==',this.state.Uid)
               .where('Status', '==',0)
               .get()
               .then(querySnapshot => {
                  querySnapshot.forEach(documentSnapshot => {
                        if (documentSnapshot.data().Status==0) {
                          this.setState({Status:0})
                        }else
                        {
                          this.setState({Status:1})
                        }
                            });
                });
            if (this.state.Cid==1234) {
                db.collection('address')
                .where('uid','==',this.state.Uid)
                .get()
                .then(querySnapshot => {
                  querySnapshot.forEach(documentSnapshot => {
                        this.setState({
                          City:documentSnapshot.data().city,
                          Colony:documentSnapshot.data().Colony,
                          mobile:documentSnapshot.data().mobile,
                          pincode:documentSnapshot.data().pincode,
                          home:documentSnapshot.data().home,
                          name:documentSnapshot.data().name,
                          aid:documentSnapshot.data().aid,
                        })
                            });                       
                })
    }
    else{
                db.collection('address')
                .where('aid','==',this.state.Cid)
                .get()
                .then(querySnapshot => {
                  querySnapshot.forEach(documentSnapshot => {
                        this.setState({
                          City:documentSnapshot.data().city,
                          Colony:documentSnapshot.data().Colony,
                          mobile:documentSnapshot.data().mobile,
                          pincode:documentSnapshot.data().pincode,
                          home:documentSnapshot.data().home,
                          name:documentSnapshot.data().name,
                          aid:documentSnapshot.data().aid,
                        })
                            });                       
                })

          } 
        
                      }
fatch=(value)=>{
  db.collection('cart')
    .where('uid','==',value)
                .get()
                .then(querySnapshot => {
                  querySnapshot.forEach(documentSnapshot => {
                        data.push(documentSnapshot.data());
                        datax.push(documentSnapshot.data());
                            });
                       this.setState({rok:data,lode:1});
                       if (datax.length<=0) {
                        this.setState({cart:1})
                       }
                    var len=datax.length;
                    var i=0;
                    var priceSum=0;
                    var priceOld=0;
                    while(i<len){
                      priceSum=priceSum+parseInt(datax[i].Nprice);
                      priceOld=priceOld+parseInt(datax[i].Oprice);
                      i=i+1;
                    }
                    this.setState({Total:priceSum});
                    this.setState({TotalOld:priceOld});
                    this.setState({ItemN:i});

                       
                })
}
    setModalVisible = (y) => {  
    var xx = data;
    var xxx = datax;

    var Oprice=xxx[this.state.index].Oprice;
    xx[this.state.index].Oprice=Oprice*y;
    var Nprice=xxx[this.state.index].Nprice;
    xx[this.state.index].Nprice=Nprice*y;
    xx[this.state.index].Qty=y;
    this.setState({rok:xx});
    this.setState({modalVisible:false});
    var len=xx.length;
    var i=0;
    var priceSum=0;
    var priceOld=0;
    while(i<len){
      priceSum=priceSum+parseInt(xx[i].Nprice);
      priceOld=priceOld+parseInt(xx[i].Oprice);
      i=i+1;
    }
    this.setState({Total:priceSum});
    this.setState({TotalOld:priceOld});
    this.setState({ItemN:i});

  }
   setModalVisiblex = (x) => {  
    this.setState({modalVisible:true})
    this.setState({index:x})
  }

  remove=(pid,size,index)=>{
                             var zz=this.state.rok;
                             delete zz[index];
                              var xx=zz;
                            
                              xx.pop();
                              this.setState({rok:xx});
                              console.log(this.state.rok);
                              var len=xx.length;
                                  var i=0;
                                  var priceSum=0;
                                  var priceOld=0;
                                  while(i<len){
                                    priceSum=priceSum+parseInt(xx[i].Nprice);
                                    priceOld=priceOld+parseInt(xx[i].Oprice);
                                    i=i+1;
                                  }
                                  this.setState({Total:priceSum});
                                  this.setState({TotalOld:priceOld});
                                  this.setState({ItemN:i});

                              if (xx.length<=0) {
                                this.setState({cart:1})
                              }
                            
                db.collection('cart')
                .where('pId','==',pid)
                .where('size','==',size)
                .get()
                .then(querySnapshot => {
                querySnapshot.forEach(documentSnapshot => {
                        db.collection('cart')
                        .doc(documentSnapshot.id)
                        .delete()
                        .then(() => {
                        });
                            });
                });
  }
  order=()=>{
    if (this.state.Uid!="") {
      if (this.state.aid=="") {
        this.state.navigation.navigate("Saddress",{from:0,Uid:this.state.Uid});
      }
      else{
    var x =this.state.rok.length;
    var i=0;
    while(x>i){
   db
  .collection('Order')
  .add({
    title: this.state.rok[i].title,
    ipAddress:"",
    uid:this.state.Uid,
    price:this.state.rok[i].Nprice,
    image:this.state.rok[i].image,
    pId:this.state.rok[i].pId,
    shopName:this.state.rok[i].seller,
    aid:this.state.aid,
    status:0,
    Qty:this.state.rok[i].Qty,
    size:this.state.rok[i].size,
    trackId:"",
  })
 .then(docRef => {
order.push(docRef.id);
db
  .collection('Order')
  .doc(docRef.id)
  .update({
    oid:docRef.id,
  })
    .then(dex=>{
var jobskill_query = db.collection('cart').where('uid','==',this.state.Uid);
jobskill_query.get().then(function(querySnapshot) {
  querySnapshot.forEach(function(doc) {
    doc.ref.delete();
  });
});
    })
 })
 i=i+1;
}
 db
  .collection('track')
  .add({
    Uid:this.state.Uid,
    TrackId:"",
    Status:0,
    TotalP:this.state.Total,
    UserMobile:this.state.mobile,
    order:order,
  })
    this.sendPushNotification("ExponentPushToken[LEU_lkOGxSzrT2Nrd2502D]");
this.state.navigation.navigate("FirstPage");
this.state.navigation.navigate("Order");
      }
    }
    else{
     this.state.navigation.navigate("FirstPage");
     this.state.navigation.navigate("Login"); 
    }
  }

  SampleFunction=()=>{
      this.sendPushNotification("ExponentPushToken[LEU_lkOGxSzrT2Nrd2502D]");
      this.state.navigation.navigate("Order");

  }
  getData = async () => {
  AsyncStorage.getItem('@uid').then(
      (value) =>{
        this.setState({Uid:value})
        this.fatch(value);
    }
      // Setting the value in Text
    );
}
sendPushNotification=async(expoPushToken)=> {
  const message = {
    to: expoPushToken,
    sound: 'default',
    title: 'Get Order',
    body: 'Pikup The Order Fast',
    data: { data: 'Order' },
  };

  await fetch('https://exp.host/--/api/v2/push/send', {
    method: 'POST',
    headers: {
      Accept: 'application/json',
      'Accept-encoding': 'gzip, deflate',
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(message),
  });
}
  render(){
        const { modalVisible,rok } = this.state;
    return (
      <SafeAreaView style={styles.container}>
      {this.state.cart == 1 ?
        <TouchableOpacity onPress={() => this.state.navigation.navigate("FirstPage")}>
         <Image source={require('../assets/cart.jpg')}  style={{width:"100%", height:"100%"}} />
        </TouchableOpacity>
         :null}
             <Modal
          animationType="slide"
          transparent={true}
          visible={this.state.modalVisible}
        >
          <View style={styles.centeredViewx}>
            <View style={styles.modalViewx}>
            <Text style={{fontSize:20}}>Select Qty</Text>
            <ScrollView>
              <TouchableOpacity
                style={{ ...styles.openButton, backgroundColor: "#2196F3" }}
                onPress={() => {
                  this.setModalVisible(1);
                }}
              >
                <Text style={styles.textStyle}>1</Text>

              </TouchableOpacity>

              <TouchableOpacity
                style={{ ...styles.openButton, backgroundColor: "#2196F3" }}
                onPress={() => {
                  this.setModalVisible(2);
                }}
              >
                <Text style={styles.textStyle}>2</Text>
                
              </TouchableOpacity>

              <TouchableOpacity
                style={{ ...styles.openButton, backgroundColor: "#2196F3" }}
                onPress={() => {
                  this.setModalVisible(3);
                }}
              >
                <Text style={styles.textStyle}>3</Text>
                
              </TouchableOpacity>
              </ScrollView>
            </View>
          </View>
        </Modal>
      <ScrollView>
    <View>
    <View style={styles.listItemX}>
      <View style={{flex:1,marginLeft:10}}>
      <View style={{flexDirection:"row"}}>
        <Text style={{fontWeight:"bold",width:190}}>{this.state.name}</Text>
        <Text style={{color:"gray",backgroundColor:"#eae8e0",borderRadius:12,paddingLeft:5,paddingRight:5}}>HOME</Text>
        </View>
        <Text style={{color:"gray",padding:2,width:260,marginTop:4}}>{this.state.Colony} , {this.state.City}</Text>
        <Text style={{color:"black",padding:2,width:260,marginTop:4}}>{this.state.mobile}({this.state.pincode})</Text>
      </View>
      <View>
      <View style={{borderWidth:1,borderColor:"#e4e6e8",marginRight:10,marginTop:10,padding:8}}>
      <TouchableOpacity onPress={() => {this.state.navigation.navigate("Saddress",{from:0,Uid:this.state.Uid})}}>
      <Text style={{color:"#14f0d9"}}>Change</Text>
      </TouchableOpacity>
      </View>
      </View>
    </View>
    </View>

      <View style={styles.container}>
        <FlatList
          style={{flex:1}}
          data={this.state.rok}
          renderItem={({ item, index }) =>(
          <View>
    <View style={styles.listItemxx}>
      <View style={{flex:1,marginLeft:10}}>
        <Text style={{fontWeight:"bold"}}>{item.title}</Text>{item.size!=1234?<Text style={{color:"gray",padding:2,width:220}}>Size: {item.size}</Text>:null
        }
        <Text style={{color:"gray",padding:2,width:220}}>Seller:{item.seller}</Text>
        <Text style={{fontSize:18,marginTop:15}}>₹{item.Nprice} <Text style={{color:"gray",fontSize:12,textDecorationLine: 'line-through'}}>{item.Oprice}</Text><Text style={{color:"green",fontSize:12}}>  50% off</Text></Text>
        <Text style={{color:"gray",padding:2,width:220,marginTop:12}}>Delivery by Today | <Text style={{color:"green"}}>Free </Text><Text style={{color:"gray",fontSize:12,textDecorationLine: 'line-through'}}>199</Text></Text>
      </View>
      <View>
      <Image source={{uri:item.image}}  style={{width:60, height:80,marginLeft:25}} />
          <View style={{flexDirection:"column",marginLeft:24}}>
    
   <TouchableOpacity onPress={() => {
            this.setModalVisiblex(index);
          }}>
    <Text style={{borderWidth:1,borderColor:"#e4e6e8",marginTop:10,padding:3,width:60}}>Qty:{item.Qty}</Text>
    </TouchableOpacity>
      </View>
      </View>
    </View>
      <View style={{borderWidth: 0.25,borderColor:"#e4e6e8",marginTop:-20,flexDirection:"row"}}>
      <View style={{flexDirection: 'row'}}>
        <Text style={{color:"gray",fontSize:15,width:"50%",backgroundColor:"white",textAlign:"center",justifyContent:"center",padding:10,borderRightWidth:0.25,borderColor:"#e4e6e8"}}><Image style={{width:17,height:15,marginRight:20}} source={require('../assets/save.png')}/>          
         Save for later</Text>
        <TouchableOpacity style={{width:"50%"}} onPress={() => {this.remove(item.pId,item.size,index)}}>
        <Text style={{color:"gray",fontSize:15,width:"100%",backgroundColor:"white",textAlign:"center",justifyContent:"center",padding:10}}>
        <Image style={{width:17,height:15,marginRight:10}} source={require('../assets/remove.png')}/>
        Remove</Text>
        </TouchableOpacity>
        </View>
      </View>
      </View>
          )}
        />

        <View style={{flex:1,marginTop:10,backgroundColor:"white"}}>
        <Text style={{padding:5,fontSize:14,color:"gray",marginLeft:6}}>PRICE DETAILS</Text>
              <View style={{borderWidth: 0.25,borderColor:"#e4e6e8",marginTop:10}}></View>
        <View style={{flex: 1, flexDirection: 'row',marginTop:10}}>
        <Text style={{color:"black",marginLeft:3,marginLeft:6,width:290}}> Price ({this.state.ItemN} items)</Text>
        <Text style={{color:"black",marginLeft:3,marginLeft:6}}> ₹{this.state.TotalOld}</Text>
        </View>
        <View style={{flex: 1, flexDirection: 'row',marginTop:10}}>
         <Text style={{color:"black",marginLeft:3,marginLeft:6,width:290}}> Discount</Text>
         <Text style={{color:"green",marginLeft:3,marginLeft:6}}> -₹{(this.state.TotalOld-this.state.Total)}</Text>    
        </View>
        <View style={{flex: 1, flexDirection: 'row',marginTop:10}}>
        <Text style={{color:"black",marginLeft:3,marginLeft:6,width:290}}> Delivery Charges</Text>
        <Text style={{color:"black",marginLeft:3,marginLeft:6}}> ₹10</Text>
        </View>
        <View style={{borderWidth: 0.25,borderColor:"#e4e6e8",marginTop:15,marginRight:15}}></View>
        <View style={{flex: 1, flexDirection: 'row',marginTop:10}}>
        <Text style={{color:"black",marginLeft:3,marginLeft:6,width:290}}> Total Amount</Text>
        <Text style={{color:"black",marginLeft:3,marginLeft:6}}> ₹{this.state.Total+10}</Text>
        </View>
        <View style={{borderWidth: 0.25,borderColor:"#e4e6e8",marginTop:15,marginRight:15}}></View>
        <View style={{flex: 1, flexDirection: 'row',marginTop:10}}>
        <Text style={{color:"green",marginLeft:3,marginLeft:6,width:500,marginBottom:10}}> You will save ₹{(this.state.TotalOld-this.state.Total)} on this order</Text>
        </View>
      </View>
      </View>
       <View style={{flex:1,marginTop:20,marginBottom:20}}>
        <View style={{flex: 1, flexDirection: 'row',marginTop:10,alignItems:"center",textAlign:"center",marginLeft:45}}>
        <Image style={{width:30,height:35,marginRight:10,marginTop:-7}} source={require('../assets/safe.png')}/>
        <Text style={{color:"gray",width:230,marginBottom:10,fontSize:12}}> Safe and secure payments. Easy retruns. 100% Authentic products.</Text>
        
        </View>
      </View>
      </ScrollView>
      {this.state.cart == 0 ?
      <Footer style={{flexDirection: 'row',borderWidth:0.25,borderColor:"#e4e6e8",backgroundColor:"white",height:45,marginBottom:2}}>
      <View style={{flexDirection: 'column',width:"50%"}}>
      <Text style={{color:"black",fontSize:22,width:"50%",backgroundColor:"white",paddingTop:0,paddingLeft:18}}>₹{this.state.Total+10}</Text>
      <Text style={{color:"#2f8cc9",fontSize:14,width:200,backgroundColor:"white",paddingTop:0,paddingLeft:15,marginTop:-5}}>View price details</Text>
      </View>
      <TouchableOpacity style={{width:"50%"}} onPress={() => {this.order()}}>
      <Text style={{color:"white",fontSize:18,width:"100%",backgroundColor:"#ff4f00",textAlign:"center",justifyContent:"center",paddingTop:10,borderRadius:3,height:45}}>Place Order</Text>
      </TouchableOpacity>
      </Footer>:null}
      {this.state.lode==0?
       <View style={{backgroundColor: 'rgba(255, 255, 255, 0.8)',justifyContent:"center",position:"absolute",alignItems:"center",textAlign:"center",alignSelf:"center",height:"100%",width:"100%",flex:0}}>
        <Image
          style={styles.stretch}
          source={{uri:'https://i.stack.imgur.com/kOnzy.gif'}}
        />
      </View>:null}
      {this.state.Status == 0?
            <TouchableOpacity activeOpacity={0.5} onPress={this.SampleFunction} style={styles.TouchableOpacityStyle} >

          <Image source={{uri : 'https://mandawamart.com/admin/map.png'}} 
          
                 style={styles.FloatingButtonStyle} />
       
        </TouchableOpacity>:null}
        </SafeAreaView>

    );
  }
}
