import React, { Component } from 'react';
import { View, Image, StyleSheet,Dimensions,TouchableOpacity,FlatList, Text, SafeAreaView, ScrollView,ActivityIndicator} from 'react-native';
import styled from 'styled-components/native'
import SwiperFlatList from 'react-native-swiper-flatlist';
import ViewPager from '@react-native-community/viewpager'
import firebase from '../pages/firebase.js';
import styles from "./styles"
const db = firebase.firestore();
import {
  Container,
  Header,
  Content,
  Left,
  Right,
  Body,
  Icon,
  ListItem,
  Thumbnail,
  Input,
  Footer,
  Item
} from 'native-base';
import { LinearGradient } from 'expo-linear-gradient';
import AsyncStorage from '@react-native-community/async-storage';
export const { width, height } = Dimensions.get('window');

import cat from '../services/api'
const catx="Man cloths with today offer";
const userx =[{"username":"praveen"},];
class DisplayAnImageWithStyle extends Component {
    constructor({route,navigation}){
      navigation.setOptions({ headerShown: false });
    super();
    this.state = {
      allUsers: userx,
      usersFiltered: userx,
      navigation:navigation,
      Data:[],
      Uid:"",
      Status:1,
    };
    this.state.navigation.setOptions({ headerShown: false });
    navigation.setOptions({ headerShown: false });
  }
  componentDidMount() {
    this.getData();
    db.collection('track')
               .where('Uid', '==',this.state.Uid)
               .where('Status', '==',0)
               .get()
               .then(querySnapshot => {
                  querySnapshot.forEach(documentSnapshot => {
                        if (documentSnapshot.data().Status==0) {
                          this.setState({Status:0})
                        }else
                        {
                          this.setState({Status:1})
                        }
                            });
                });

      var catx=cat.length;
      var i=0;
      while(catx>=i){
        cat.pop();
        i=i+1;
      }
      this.fatch();
      
    }
      fatch=()=>{
               db.collection('cat')
                .get()
                .then(querySnapshot => {
                  querySnapshot.forEach(documentSnapshot => {
                        cat.push(documentSnapshot.data());
                            });
                  this.setState({Data:cat})
                });

                }
                  SampleFunction=()=>{

      this.state.navigation.navigate("Order");

  }
getData = async () => {
  AsyncStorage.getItem('@uid').then(
      (value) =>{
        // AsyncStorage returns a promise
        // Adding a callback to get the value
        this.setState({Uid:value})
        if (value) {}
        else{
          this.state.navigation.navigate("Login")
      }
    }
      // Setting the value in Text
    );
}
  render() {

    return (
    <SafeAreaView style={styles.containeri}>
      <Header style={{backgroundColor:'#1cd4ee',height:60}} searchBar rounded>
      <TouchableOpacity onPress={() => this.state.navigation.goBack()}>
      <Icon style={{marginTop:17,color:"white",marginLeft:-20}} name="ios-arrow-back" color="white"/>
      </TouchableOpacity>
      <Text style={{position:"relative",color:"white",fontSize:18,marginLeft:0,marginTop:17,width:130}}>All Categories</Text>
      <TouchableOpacity onPress={() => this.state.navigation.navigate("Search")}>
      <Icon style={{marginTop:17,color:"white",marginLeft:60}} name="ios-search" color="white"/>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => this.state.navigation.navigate("Cart",{Catid:1234})}>
      <Icon style={{marginTop:17,color:"white",marginLeft:60}} name="ios-cart" color="white"/>
      </TouchableOpacity>
      <Text style={{position:"relative",color:"red",fontSize:20,marginLeft:-17,marginTop:5,fontWeight:"bold",width:20,height:22,borderRadius:100,paddingLeft:5}}>5</Text>
        </Header>
        
    <ScrollView>
    <View>
        <View style={styles.MainContaineri}>
        <LinearGradient colors={['white', 'gray']}>
        <FlatList
          data={this.state.Data}
          renderItem={({ item }) => (
            <View style={{ flex: 1, flexDirection: 'column', margin: 1,height:210,backgroundColor:"white",justifyContent:"center",alignItems:"center",borderRadius:10 }}>
            <TouchableOpacity onPress={() => this.state.navigation.navigate(item.type,{Pid:item.catId,Cat:item.title})}>
              <Image style={styles.imageThumbnaili} source={{uri: item.image}}/>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => this.state.navigation.navigate(item.type,{Pid:item.catId,Cat:item.title})}>
              <Text style={{justifyContent:"center",textAlign:"center",marginTop:0}}>{item.title}</Text>
              </TouchableOpacity>
            </View>
          )}
          //Setting the number of column
          numColumns={2}
        />
        </LinearGradient>
      </View>      
</View>
            </ScrollView>
            {this.state.Status == 0?
            <TouchableOpacity activeOpacity={0.5} onPress={this.SampleFunction} style={styles.TouchableOpacityStyle} >

          <Image source={{uri : 'https://mandawamart.com/admin/map.png'}} 
          
                 style={styles.FloatingButtonStyle} />
       
        </TouchableOpacity>:null}
        </SafeAreaView>
    );
  }
}

export default DisplayAnImageWithStyle;