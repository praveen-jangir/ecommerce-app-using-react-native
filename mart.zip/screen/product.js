import React, { Component } from 'react';
import { View, Image, StyleSheet,Dimensions,TouchableOpacity,FlatList, Text, SafeAreaView, ScrollView,ActivityIndicator} from 'react-native';
import styled from 'styled-components/native'
import SwiperFlatList from 'react-native-swiper-flatlist';
import ViewPager from '@react-native-community/viewpager'
import AsyncStorage from '@react-native-community/async-storage';       
import styles from "./styles"
import Head from './head'
import {
  Container,
    Header,
  Content,
  Left,
  Right,
  Body,
  Icon,
  ListItem,
  Thumbnail,
  Input,
  Footer,
} from 'native-base';
import firebase from '../pages/firebase.js';
const db = firebase.firestore();
export const { width, height } = Dimensions.get('window');
function Item({ item,navigation}) {
  return (<View style={{ flex: 1, flexDirection: 'column',height:260,backgroundColor:"white",width:"100%"}}>
            <TouchableOpacity onPress={() => navigation.navigate("productView",{Pid:item.pId,Fimage:item.Fimage,Cat:item.catId})}>
              <Image style={styles.imageThumbnail} source={{uri: item.Fimage}}/>
              </TouchableOpacity>
              <TouchableOpacity>
                            <Icon style={{color:"gray",marginLeft:140,position:"absolute",borderRadius:100,width:30,height:30,backgroundColor:"white",paddingLeft:3,paddingRight:1,paddingTop:2,paddingBottom:2,bottom:5}} name="ios-cart" color="white"/>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => navigation.navigate("productView",{Pid:item.pId,Fimage:item.Fimage,Cat:item.catId
              })} style={{paddingLeft:10}}>
              <Text style={{}}>{item.title}</Text>
              <Text style={{color:"gray"}}>{item.shopName}</Text>
              <Text style={{fontSize:15}}>₹{item.newPrice} <Text style={{color:"gray",fontSize:12,textDecorationLine: 'line-through'}}>{item.oldPrice}</Text><Text style={{color:"green",fontSize:12}}>  50% off</Text></Text>
            </TouchableOpacity>
            </View>
            );
}
const catx="Man cloths with today offer";
const cat = [];
const videos=[];
const Lproduct=[];
const userx =[{"username":"praveen"},];
class DisplayAnImageWithStyle extends Component {
    constructor({route,navigation}){
      const {Pid,Cat} =route.params;
      db.collection('Product')
                .where('catId','==',Pid)
                .get()
                .then(querySnapshot => {
                  querySnapshot.forEach(documentSnapshot => {
                        videos.push(documentSnapshot.data());
                        var x=videos.length;
                   /*     if (x%2==0 && x==1) {
                        }
                        else{
                          if (x==1) {
                          }
                          else{
                            videos.pop();
                          }
                        }*/
                  console.log(videos);
                            });
                });
    super();
    this.state = {
      allUsers: userx,
      usersFiltered: userx,
      navigation:navigation,
      catId:Pid,
      Data:[],
      Status:1,
      Uid:"",
      lode:0,
      Cat:Cat,

    };
  }

    componentDidMount() {
      this.getData();
    db.collection('track')
               .where('Uid', '==',this.state.Uid)
               .where('Status', '==',0)
               .get()
               .then(querySnapshot => {
                  querySnapshot.forEach(documentSnapshot => {
                        if (documentSnapshot.data().Status==0) {
                          this.setState({Status:0})
                        }else
                        {
                          this.setState({Status:1})
                        }
                            });
                });
      var len=Lproduct.length;
      var i=0;
      while(len>=i){
        Lproduct.pop();
        i=i+1;
      }
      this.fatch();
    }
      fatch=()=>{
                db.collection('Product')
                .where('catId','==',this.state.catId)
                .get()
                .then(querySnapshot => {
                  querySnapshot.forEach(documentSnapshot => {
                        Lproduct.push(documentSnapshot.data());
                        this.setState({Data:Lproduct,lode:1})
                            });
                });

                }
                SampleFunction=()=>{

      this.state.navigation.navigate("Order");

  }
   getData = async () => {
  AsyncStorage.getItem('@uid').then(
      (value) =>{
        // AsyncStorage returns a promise
        // Adding a callback to get the value
        this.setState({Uid:value})
    }
      // Setting the value in Text
    );
}
  render() {

    return (
    <SafeAreaView style={styles.containeri}>
      <Head Cat={this.state.Cat}/>  
    <ScrollView>
    <View>
        <View style={{paddingLeft:7}}>
        <FlatList
          data={this.state.Data}
          renderItem={({ item }) => <Item item={item} navigation={this.state.navigation}/>}
          
          numColumns={2}
        />
      </View>
       </View>
            </ScrollView>
            {this.state.lode==0?
       <View style={{backgroundColor: 'rgba(255, 255, 255, 0.8)',justifyContent:"center",position:"absolute",alignItems:"center",textAlign:"center",alignSelf:"center",height:"100%",width:"100%",flex:0}}>
        <Image
          style={styles.stretch}
          source={{uri:'https://i.stack.imgur.com/kOnzy.gif'}}
        />
      </View>:null}
            {this.state.Status == 0?
            <TouchableOpacity activeOpacity={0.5} onPress={this.SampleFunction} style={styles.TouchableOpacityStyle} >

          <Image source={{uri : 'https://mandawamart.com/admin/map.png'}} 
          
                 style={styles.FloatingButtonStyle} />
       
        </TouchableOpacity>:null}
        </SafeAreaView>
    );
  }
}

export default DisplayAnImageWithStyle;