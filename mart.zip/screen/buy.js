import React from 'react';
import { StyleSheet, Text, View, FlatList, Image, TouchableOpacity,Picker, SafeAreaView, ScrollView,Modal, } from 'react-native';
import {
  Container,
    Header,
  Content,
  Left,
  Right,
  Body,
  Icon,
  ListItem,
  Thumbnail,
  Input,
  Footer,
} from 'native-base';
import styles from "./styles"
import firebase from '../pages/firebase.js';
import AsyncStorage from '@react-native-community/async-storage';
const db = firebase.firestore();
const cat="Man cloths with today offer";
const order=[];
export default class App extends React.Component {
  constructor({route,navigation}){
      const {Pid,Size,Cid} =route.params;
   super();
    this.state = {
      uid:"",
      pid:Pid,
      title:"",
      Fimage:"",
      nPrice:1,
      oPrice:1,
      uPrice:1,
      dis:"",
      navigation:navigation,
      Value:1,
      modalVisible: false,
      disx:0,
      size:Size,
      seller:"",
      Cid:Cid,
      address:"",
      name:"Address not found",
      mobile:"",
      Colony:"",
      pincode:"",
      home:'',
      City:'',
      aid:'',
      Uid:"",
      ouPrice:1,
      Status:1,
      data:[
        {
            "name": "Miyah Myles",
            "email": "miyah.myles@gmail.com",
            "position": "Data Entry Clerk",
            "photo": "https:\/\/images.unsplash.com\/photo-1494790108377-be9c29b29330?ixlib=rb-0.3.5&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=200&fit=max&s=707b9c33066bf8808c934c8ab394dff6"
        },
    ],
    lode:0,
    };
   this.getData();
    db.collection('track')
               .where('Uid', '==',this.state.Uid)
               .where('Status', '==',0)
               .get()
               .then(querySnapshot => {
                  querySnapshot.forEach(documentSnapshot => {
                        if (documentSnapshot.data().Status==0) {
                          this.setState({Status:0})
                        }else
                        {
                          this.setState({Status:1})
                        }
                            });
                });
    db.collection('Product')
                .where('pId','==',Pid)
                .get()
                .then(querySnapshot => {
                  querySnapshot.forEach(documentSnapshot => {
                  this.setState({
                    title:documentSnapshot.data().title,
                    nPrice:documentSnapshot.data().newPrice,
                    uPrice:documentSnapshot.data().newPrice,
                    oPrice:documentSnapshot.data().oldPrice,
                    dis:documentSnapshot.data().dis,
                    Fimage:documentSnapshot.data().Fimage,
                    seller:documentSnapshot.data().shopName,
                    lode:1
                  })

                    var dis=this.state.oPrice-this.state.nPrice;
                    var tx =dis/this.state.oPrice*100;
                    this.setState({disx:parseInt(tx)});
                            });
                });
                if (Cid==1234) {
                db.collection('address')
                .where('uid','==',this.state.Uid)
                .get()
                .then(querySnapshotx => {
                  querySnapshotx.forEach(documentSnapshot => { 
                        this.setState({
                          City:documentSnapshot.data().city,
                          Colony:documentSnapshot.data().Colony,
                          mobile:documentSnapshot.data().mobile,
                          pincode:documentSnapshot.data().pincode,
                          home:documentSnapshot.data().home,
                          name:documentSnapshot.data().name,
                          aid:documentSnapshot.data().aid,
                        }).catch(()=>{alert("")})
                            });                       
                })
                   }
    else{
                db.collection('address')
                .where('aid','==',Cid)
                .get()
                .then(querySnapshot => {
                  querySnapshot.forEach(documentSnapshot => {
                        this.setState({
                          City:documentSnapshot.data().city,
                          Colony:documentSnapshot.data().Colony,
                          mobile:documentSnapshot.data().mobile,
                          pincode:documentSnapshot.data().pincode,
                          home:documentSnapshot.data().home,
                          name:documentSnapshot.data().name,
                          aid:documentSnapshot.data().aid,
                        })
                            });                       
                })

          }


  }
    setModalVisible = (visible,x) => {
    this.setState({ modalVisible: visible,Value:x });
    var Bprice = this.state.nPrice;
    var qty=x;
    var total=qty*Bprice;
    this.setState({uPrice:qty*Bprice})
  }
order=()=>{
  if (this.state.aid=="") {
        this.state.navigation.navigate("Saddress",{from:0,Uid:this.state.Uid});
      }else{
   db
  .collection('Order')
  .add({
    title: this.state.title,
    ipAddress:"",
    uid:this.state.uid,
    price:this.state.nPrice,
    image:this.state.Fimage,
    pId:this.state.pid,
    shopName:this.state.seller,
    aid:"",
    Qty:this.state.Value,
    size:this.state.size,
    trackId:"",
    status:0
  })
 .then(docRef => {

      order.push(docRef.id);
  db
  .collection('Order')
  .doc(docRef.id)
  .update({
    oid:docRef.id,
  })
    .then(dex=>{
  db
  .collection('track')
  .add({
    Uid:this.state.uid,
    TrackId:"",
    Status:0,
    TotalP:parseInt(this.state.uPrice)+10,
    UserMobile:this.state.mobile,
    order:order,
  })
    })
});
 this.sendPushNotification("ExponentPushToken[LEU_lkOGxSzrT2Nrd2502D]");
this.state.navigation.navigate("FirstPage");
this.state.navigation.navigate("Order");
  }
}
  SampleFunction=()=>{
    this.sendPushNotification("ExponentPushToken[LEU_lkOGxSzrT2Nrd2502D]");
      this.state.navigation.navigate("Order");
  }
sendPushNotification=async(expoPushToken)=> {
  const message = {
    to: expoPushToken,
    sound: 'default',
    title: 'Get Order',
    body: 'Pikup The Order Fast',
    data: { data: 'Order' },
  };

  await fetch('https://exp.host/--/api/v2/push/send', {
    method: 'POST',
    headers: {
      Accept: 'application/json',
      'Accept-encoding': 'gzip, deflate',
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(message),
  });
}
getData = async () => {
  try {
    const value = await AsyncStorage.getItem('@uid')
    if(value !== null) {
     this.setState({uid:value,Uid:value});
    }
    else{
          this.state.navigation.navigate("Login");
    }
  } catch(e) {
    // error reading value
  }
}
  render(){

    const { modalVisible } = this.state;
    return (
      <SafeAreaView style={styles.container}>
       <Modal
          animationType="slide"
          transparent={true}
          visible={this.state.modalVisible}
        >
          <View style={styles.centeredViewx}>
            <View style={styles.modalViewx}>
            <Text style={{fontSize:20}}>Select Qty</Text>
            <ScrollView>
              <TouchableOpacity
                style={{ ...styles.openButton, backgroundColor: "#2196F3" }}
                onPress={() => {
                  this.setModalVisible(!modalVisible,1);
                }}
              >
                <Text style={styles.textStyle}>1</Text>

              </TouchableOpacity>

              <TouchableOpacity
                style={{ ...styles.openButton, backgroundColor: "#2196F3" }}
                onPress={() => {
                  this.setModalVisible(!modalVisible,2);
                }}
              >
                <Text style={styles.textStyle}>2</Text>
                
              </TouchableOpacity>

              <TouchableOpacity
                style={{ ...styles.openButton, backgroundColor: "#2196F3" }}
                onPress={() => {
                  this.setModalVisible(!modalVisible,3);
                }}
              >
                <Text style={styles.textStyle}>3</Text>
                
              </TouchableOpacity>
              </ScrollView>
            </View>
          </View>
        </Modal>
      <ScrollView>
    <View>
    <View style={styles.listItemXb}>
      <View style={{flex:1,marginLeft:10}}>
      <View style={{flexDirection:"row"}}>
        <Text style={{fontWeight:"bold",width:190}}>{this.state.name}</Text>
        <Text style={{color:"gray",backgroundColor:"#eae8e0",borderRadius:12,paddingLeft:5,paddingRight:5}}>HOME</Text>
        </View>
        <Text style={{color:"#524f4f",padding:2,width:260,marginTop:4}}>{this.state.home} , {this.state.Colony}</Text>
        <Text style={{color:"#524f4f",padding:1,width:260,marginTop:2}}>{this.state.City}-{this.state.pincode} </Text>
        <Text style={{color:"#524f4f",padding:1,width:260,marginTop:2}}>{this.state.mobile}</Text>
<View style={{borderColor:"#ff9100",borderWidth:0.7,backgroundColor:"#ffefe0",width:325,marginTop:7}}>
        <Text style={{color:"#524f4f",padding:7,width:340,marginTop:2,fontSize:13}}>Please check if the address is suitable for collecting delivery</Text>
</View>
<View style={{borderColor:"white",borderWidth:0.7,backgroundColor:"#0264d3",width:325,marginTop:17,paddingLeft:10,paddingRight:10,paddingTop:7,paddingBottom:7,borderRadius:5}}>
       <TouchableOpacity onPress={() => {this.state.navigation.navigate("Saddress",{from:1,Pid:this.state.pid,Size:this.state.size,Uid:this.state.Uid})}}>
        <Text style={{color:"white",width:340,marginTop:2,textAlign:"center",marginLeft:-15}}>Change or Add Address</Text>
       </TouchableOpacity>
</View>
      </View>
      <View>
      </View>
    </View>
      </View>


      <View style={styles.container}>
        <FlatList
          style={{flex:1}}
          data={this.state.data}
          renderItem={({ item }) =>(
          <View>
          <View style={styles.listItemb}>
          <View style={{flex:1,marginLeft:10}}>
          <Text style={{fontWeight:"bold"}}>{this.state.title}</Text>
          {this.state.size!=1234?<Text style={{color:"gray",padding:2,width:220}}>Size: {this.state.size}</Text>:null
        }
          <Text style={{color:"gray",padding:2,width:220}}>Seller: M-Mart online Store</Text>
          <Text style={{fontSize:18,marginTop:15}}>₹{this.state.uPrice} <Text style={{color:"gray",fontSize:12,textDecorationLine: 'line-through'}}>{this.state.oPrice}</Text><Text style={{color:"green",fontSize:12}}>  50% off</Text></Text>
          <Text style={{color:"gray",padding:2,width:220,marginTop:12}}>Delivery by Today | <Text style={{color:"green"}}>Free </Text><Text style={{color:"gray",fontSize:12,textDecorationLine: 'line-through'}}>199</Text></Text>
          </View>
      <View>
      <Image source={{uri:item.photo}}  style={{width:60, height:80,marginLeft:25}} />
      <View style={{flexDirection:"column",marginLeft:24}}>
    
   <TouchableOpacity onPress={() => {
            this.setModalVisible(true);
          }}>
    <Text style={{borderWidth:1,borderColor:"#e4e6e8",marginTop:10,padding:3,width:60}}>Qty:{this.state.Value}</Text>
    </TouchableOpacity>
      </View>
      </View>
    </View>
      <View style={{borderWidth: 0.25,borderColor:"#e4e6e8",marginTop:-20,flexDirection:"row"}}>
      </View>
      </View>
          )}
          keyExtractor={item => item.email}
        />




        <View style={{flex:1,marginTop:10,backgroundColor:"white"}}>
        <Text style={{padding:5,fontSize:14,color:"gray",marginLeft:6}}>PRICE DETAILS</Text>
              <View style={{borderWidth: 0.25,borderColor:"#e4e6e8",marginTop:10}}></View>
        <View style={{flex: 1, flexDirection: 'row',marginTop:10}}>
        <Text style={{color:"black",marginLeft:3,marginLeft:6,width:290}}> Price </Text>
        <Text style={{color:"black",marginLeft:3,marginLeft:6}}> ₹{(this.state.oPrice)*(this.state.Value)}</Text>
        </View>
        <View style={{flex: 1, flexDirection: 'row',marginTop:10}}>
         <Text style={{color:"black",marginLeft:3,marginLeft:6,width:290}}> Discount</Text>
         <Text style={{color:"green",marginLeft:3,marginLeft:6}}> -₹{(this.state.oPrice-this.state.nPrice)*this.state.Value}</Text>    
        </View>
        <View style={{flex: 1, flexDirection: 'row',marginTop:10}}>
        <Text style={{color:"black",marginLeft:3,marginLeft:6,width:290}}> Delivery Charges</Text>
        <Text style={{color:"black",marginLeft:3,marginLeft:6}}> ₹10</Text>
        </View>
        <View style={{borderWidth: 0.25,borderColor:"#e4e6e8",marginTop:15,marginRight:15}}></View>
        <View style={{flex: 1, flexDirection: 'row',marginTop:10}}>
        <Text style={{color:"black",marginLeft:3,marginLeft:6,width:290}}> Total Charges</Text>
        <Text style={{color:"black",marginLeft:3,marginLeft:6}}> ₹{parseInt(this.state.uPrice)+10}</Text>
        </View>
        <View style={{borderWidth: 0.25,borderColor:"#e4e6e8",marginTop:15,marginRight:15}}></View>
        <View style={{flex: 1, flexDirection: 'row',marginTop:10}}>
        <Text style={{color:"green",marginLeft:3,marginLeft:6,width:500,marginBottom:10}}> You will save ₹{(this.state.oPrice-this.state.nPrice)*this.state.Value} on this order</Text>
        </View>
      </View>
      </View>
       <View style={{flex:1,marginTop:20,marginBottom:20}}>
        <View style={{flex: 1, flexDirection: 'row',marginTop:10,alignItems:"center",textAlign:"center",marginLeft:45}}>
        <Image style={{width:30,height:35,marginRight:10,marginTop:-7}} source={require('../assets/safe.png')}/>
        <Text style={{color:"gray",width:230,marginBottom:10,fontSize:12}}> Safe and secure payments. Easy retruns. 100% Authentic products.</Text>
        
      </View>
      </View>
      </ScrollView>
      <Footer style={{flexDirection: 'row',borderWidth:0.25,borderColor:"#e4e6e8",backgroundColor:"white",height:45,marginBottom:2}}>
      <View style={{flexDirection: 'column',width:"50%"}}>
      <Text style={{color:"black",fontSize:22,width:"50%",backgroundColor:"white",paddingTop:0,paddingLeft:18}}>₹{parseInt(this.state.uPrice)+10}</Text>
      <Text style={{color:"#2f8cc9",fontSize:14,width:200,backgroundColor:"white",paddingTop:0,paddingLeft:15,marginTop:-5}}>View price details</Text>
      </View>
      <TouchableOpacity style={{width:"50%"}} onPress={() => {this.order()}}>
      <Text style={{color:"white",fontSize:18,width:"100%",backgroundColor:"#ff4f00",textAlign:"center",justifyContent:"center",paddingTop:10,borderRadius:8,height:45}}>CONTINUE</Text>
      </TouchableOpacity>
      </Footer>
      {this.state.lode==0?
       <View style={{backgroundColor: 'rgba(255, 255, 255, 0.8)',justifyContent:"center",position:"absolute",alignItems:"center",textAlign:"center",alignSelf:"center",height:"100%",width:"100%",flex:0}}>
        <Image
          style={styles.stretch}
          source={{uri:'https://i.stack.imgur.com/kOnzy.gif'}}
        />
      </View>:null}
      {this.state.Status == 0?
            <TouchableOpacity activeOpacity={0.5} onPress={this.SampleFunction} style={styles.TouchableOpacityStyle} >

          <Image source={{uri : 'https://mandawamart.com/admin/map.png'}} 
          
                 style={styles.FloatingButtonStyle} />
       
        </TouchableOpacity>:null}
        </SafeAreaView>
    );
  }
}

