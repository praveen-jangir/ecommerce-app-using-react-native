import React, { Component } from "react";
import { View } from "native-base";
import AsyncStorage from '@react-native-community/async-storage';
class Logout extends React.Component {
constructor({route,navigation}){
  super();
  this.state={navigation:navigation,
    }
  }
componentDidMount(){
this.clearAll();
}
clearAll = async () => {
  try {
    await AsyncStorage.clear()
  } catch(e) {
    // clear error
  }
  this.state.navigation.navigate("Login")
}
  render () {
    return (
      <View>
      </View>
    )
  }
}

export default Logout