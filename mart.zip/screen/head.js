import React, { Component } from 'react';
import { StyleSheet, Text, View,TouchableOpacity } from 'react-native';
import {
  Container,
  Header,
  Content,
  Left,
  Right,
  Body,
  Icon,
  ListItem,
  Thumbnail,
  Input,
  Footer,
} from 'native-base';
import firebase from '../pages/firebase.js';
import AsyncStorage from '@react-native-community/async-storage';
const db = firebase.firestore();

export default class Head extends Component {
      constructor({route,navigation,Cat}){
            super();
      this.state = {
      navigation:navigation,
      Data:[],
      Status:1,
      lode:0,
      this:this,
      Cat:Cat,
      catNo:0,
      Uid:"",
    };  
     }
      componentDidMount() {
        this.getData();
          this.catNox();
           }
           catNox=()=>{
               db.collection('cart')
               .where('uid', '==',this.state.Uid)
               .get()
               .then(querySnapshot => {
                this.catNox();
                var i=0
                  querySnapshot.forEach(documentSnapshot => {
                    i=i+1;
                        if (documentSnapshot.data().Status==0) {
                          this.setState({Status:0})
                        }else
                        {
                          this.setState({Status:1})
                        }
                        this.setState({catNo:i})
                            });
                });
}
getData = async () => {
  AsyncStorage.getItem('@uid').then(
      (value) =>{
        // AsyncStorage returns a promise
        // Adding a callback to get the value
        this.setState({Uid:value})
        if (value) {}
        else{
          this.state.navigation.navigate("Login")
      }
    }
      // Setting the value in Text
    );
}
  render() {
    return (
      <Header style={{backgroundColor:'white',height:60}} searchBar rounded>
      <TouchableOpacity onPress={() => this.state.navigation.goBack()}>
      <Icon style={{marginTop:17,color:"#1cd4ee",marginLeft:-10,marginRight:10}} name="ios-arrow-back" color="white"/>
      </TouchableOpacity>
      <Text style={{position:"relative",color:"#1cd4ee",fontSize:16,marginLeft:10,marginTop:17,width:150}}>{this.state.Cat}</Text>
      <TouchableOpacity onPress={() => this.state.navigation.navigate("Search")}>
      <Icon style={{marginTop:17,color:"#1cd4ee",marginLeft:10}} name="ios-search" color="white"/>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => this.state.navigation.navigate("Cart",{Cid:1234})}>
      <Icon style={{marginTop:17,color:"#1cd4ee",marginLeft:30}} name="ios-cart" color="#1cd4ee"/>
      </TouchableOpacity>
      <Text style={{position:"relative",color:"#1cd4ee",fontSize:16,marginLeft:-17,marginTop:5,fontWeight:"bold",width:22,height:22,borderRadius:100,backgroundColor:"orange",height:21,width:21,textAlign:"center",borderRadius:100}}>{this.state.catNo}</Text>
      </Header>
);
}
}

      