import React, { Component } from 'react';
import { View, Image, StyleSheet,Dimensions,TouchableOpacity,FlatList, Text, SafeAreaView, ScrollView,ActivityIndicator} from 'react-native';
import styled from 'styled-components/native'
import SwiperFlatList from 'react-native-swiper-flatlist';
import ViewPager from '@react-native-community/viewpager'
import firebase from '../pages/firebase.js';
import styles from "./styles"
import * as Location from 'expo-location';
import * as Permissions from 'expo-permissions'
import * as Notifications from 'expo-notifications';
import AsyncStorage from '@react-native-community/async-storage';
const db = firebase.firestore();
import {
  Container,
  Header,
  Content,
  Left,
  Right,
  Body,
  Icon,
  ListItem,
  Thumbnail,
  Input,
  Footer,
  Item
} from 'native-base';
import { LinearGradient } from 'expo-linear-gradient';
export const { width, height } = Dimensions.get('window');

import cat from '../services/api'
const videos = [];
const videosx = [];
const videosxx = [];
const videosxx1 = [];
const videosxx2 = [];
const videosxx3 = [];

const userx =[{"username":"praveen"},];
function Itemx({ item,navigation}) {
  return (
    <View style={{ flex: 1, flexDirection: 'column', margin: 1,height:260,backgroundColor:"white",borderRadius:7,textAlign: "left",alignItems:"center"}}>
            <TouchableOpacity onPress={() => navigation.navigate("productView",{Pid:item.pId,Fimage:item.Fimage,Cat:item.catId})}>
            <View style={{alignItems:"center"}}>
              <Image style={styles.imageThumbnaili} source={{uri: item.Fimage}}/>
              </View>
              </TouchableOpacity>
              <View style={{paddingLeft:14,textAlign: "left"}}>
              <Text style={{fontSize:14,fontWeight:"bold"}}>{item.title.slice(0, 40)}</Text>
              <TouchableOpacity onPress={() => navigation.navigate("productView",{Pid:item.pId,Fimage:item.Fimage,Cat:item.catId})}>
              <Text style={{width:140,fontSize:14}}>{item.dis.slice(0, 40)}</Text>
              <Text style={{fontSize:14}}>₹{item.newPrice} <Text style={{color:"gray",fontSize:12,textDecorationLine: 'line-through'}}>{item.oldPrice}</Text><Text style={{color:"green",fontSize:12}}>  50% off</Text></Text>
            </TouchableOpacity>
            </View>
            </View>
            );
}
class DisplayAnImageWithStyle extends Component {
    constructor({route,navigation}){
      navigation.setOptions({ headerShown: false });
    super();
    this.state = {
      allUsers: userx,
      usersFiltered: userx,
      navigation:navigation,
      Data:[],
      Vdata:[],
      Vdatax:[],
      Vdataxx:[],
      Vdataxx1:[],
      Vdataxx2:[],
      Vdataxx3:[],
      Uid:"",
      Status:1,
      lode:0,
      title:"#1cd4ee",
      catNo:0,
      notification:true,latitude:0,longitude:0,
      mobile:'',
      admin:'FirstPage',
      colors:[{"name1":"#e2e3e3","name2":"#e2e3e3"},{"name1":"#e2e3e3","name2":"#e2e3e3"},{"name1":"#e2e3e3","name2":"#e2e3e3"},{"name1":"#e2e3e3","name2":"#e2e3e3"},
{"name1":"#e2e3e3","name2":"#e2e3e3"},
{"name1":"#e2e3e3","name2":"#e2e3e3"},
{"name1":"#e2e3e3","name2":"#e2e3e3"},]
    };
    this.state.navigation.setOptions({ headerShown: false });
    navigation.setOptions({ headerShown: false });
  }

  componentDidMount() {
    this._getLocationAsync();
    this.getData();
      var catx=cat.length;
      var len=videos.length;
      var lenx=videosx.length;
      var lenxx=videosxx.length;
      var lenxx1=videosxx1.length;
      var lenxx2=videosxx2.length;
      var lenxx3=videosxx3.length;
      var i=0;
      while(lenxx1>=i){
        videosxx1.pop();
        i=i+1;
      }
      while(lenxx3>=i){
        videosxx3.pop();
        i=i+1;
      }
      while(lenxx2>=i){
        videosxx2.pop();
        i=i+1;
      }
      while(lenxx>=i){
        videosxx.pop();
        i=i+1;
      }
      while(len>=i){
        videos.pop();
        i=i+1;
      }
      while(lenx>=i){
        videosx.pop();
        i=i+1;
      }
      while(catx>=i){
        cat.pop();
        i=i+1;
      }
      this.fatch();
    }

  _getLocationAsync = async () => {
   let { status } = await Permissions.askAsync(Permissions.LOCATION);
   if (status !== 'granted') {
    this._getLocationAsync();
     this.setState({
       locationResult: 'Permission to access location was denied',
     });
   } else {
     this.setState({ hasLocationPermissions: true });
   }

   let location = await Location.getCurrentPositionAsync({
   });
   this.setState({ locationResult: JSON.stringify(location) });
   // Center the map on the location we just fetched.
    this.setState({
      latitude: location.coords.latitude, longitude: location.coords.longitude,
  });}
    cartx=()=>{
    db.collection('cart')
               .where('uid', '==',this.state.Uid)
               .get()
               .then(querySnapshot => {
                var i=0
                  querySnapshot.forEach(documentSnapshot => {
                    i=i+1;
                        if (documentSnapshot.data().Status==0) {
                          this.setState({Status:0})
                        }else
                        {
                          this.setState({Status:1})
                        }
                        this.setState({catNo:i})
                            });
                });
    }
    track =()=>{
       db.collection('track')
               .where('Uid', '==',this.state.Uid)
               .where('Status', '==',0)
               .get()
               .then(querySnapshot => {
                  querySnapshot.forEach(documentSnapshot => {
                        if (documentSnapshot.data().Status==0) {
                          this.setState({Status:0})
                        }else
                        {
                          this.setState({Status:1})
                        }
                            });
                });
    }
 getData = async () => {
  AsyncStorage.getItem('@uid').then(
      (value) =>{
        // AsyncStorage returns a promise
        // Adding a callback to get the value
        AsyncStorage.getItem('@Amobile').then(
      (valuex) =>{
      this.setState({mobile:valuex})
      })
        this.setState({Uid:value})
        if (value) {}
        else{
          this.state.navigation.navigate("Login")
      }
    }
      // Setting the value in Text
    );
}
clearAll = async () => {
  try {
    await AsyncStorage.clear()
  } catch(e) {
    // clear error
  }

  console.log('Done.')
}

userLocation=(uy,ux)=>{
var minx=74.969911;
var miny=27.934082;
var maxy=28.162884;
var maxx=75.360232;
var x=maxx-minx;
var y=maxy-miny;
if (x>=(maxx-ux) && y>(maxy-uy)) {
}
else{
 alert("Fast Services Available Near Mandawa")
}
}
      fatch=()=>{

               db.collection('cat')
               .where('catId', 'in', ['003', '004','005','007','008','009','011','012','001','002'])
                .get()
                .then(querySnapshot => {
                  querySnapshot.forEach(documentSnapshot => {
                        cat.push(documentSnapshot.data());
                            });
                  this.setState({Data:cat})
                  this.setState({lode:1})
                });

               db.collection('cat')
               .where('catId', 'in', ['001', '002'])
                .get()
                .then(querySnapshot => {
                  querySnapshot.forEach(documentSnapshot => {
                        videos.push(documentSnapshot.data());
                            });
                  this.setState({Vdata:videos})
                });

                db.collection('cat')
               .where('catId', 'in', ['006', '010'])
                .get()
                .then(querySnapshot => {
                  querySnapshot.forEach(documentSnapshot => {
                        videosx.push(documentSnapshot.data());
                            });
                  this.setState({Vdatax:videosx})
                });

               db.collection('Product')
               .where('catId', 'in', ['001', '002'])
                .get()
                .then(querySnapshot => {
                  querySnapshot.forEach(documentSnapshot => {
                        videosxx.push(documentSnapshot.data());
                            });
                  this.setState({Vdataxx:videosxx})
                });

               db.collection('Product')
               .where('catId', 'in', ['007'])
                .get()
                .then(querySnapshot => {
                  querySnapshot.forEach(documentSnapshot => {
                        videosxx1.push(documentSnapshot.data());
                            });
                  this.setState({Vdataxx1:videosxx1})
                });

                db.collection('Product')
               .where('catId', 'in', ['003'])
                .get()
                .then(querySnapshot => {
                  querySnapshot.forEach(documentSnapshot => {
                        videosxx2.push(documentSnapshot.data());
                            });
                  this.setState({Vdataxx2:videosxx2})
                });

                db.collection('Product')
               .where('catId', 'in', ['002','012','005','008','001'])
                .get()
                .then(querySnapshot => {
                  querySnapshot.forEach(documentSnapshot => {
                        videosxx3.push(documentSnapshot.data());
                            });
                  this.setState({Vdataxx3:videosxx3})
                });


                }
                  SampleFunction=()=>{

      this.state.navigation.navigate("Order");

  }

  render() {

    return (
    <SafeAreaView style={styles.containeri}>
      <Header style={{backgroundColor:'#42f9e2',height:120,borderBottomWidth:1,borderColor:"#1cd4ee"}} searchBar rounded>
      <TouchableOpacity onPress={() => this.state.navigation.openDrawer()}>
      <Icon style={{marginTop:25,color:"white"}} name="ios-menu" color="white"/>
  </TouchableOpacity>
{this.state.mobile != '9649215382'?
<View>
  <TouchableOpacity onPress={() => this.state.navigation.navigate("FirstPage")}>
      <Image style={styles.Logoi} source={require('../assets/splashx.png')}/>
      </TouchableOpacity>
      </View>:
      <View>
  <TouchableOpacity onPress={() => this.state.navigation.navigate("Available Order")}>
      <Image style={styles.Logoi} source={require('../assets/splashx.png')}/>
      </TouchableOpacity>
      </View>
    }

<TouchableOpacity onPress={() => this.state.navigation.navigate("Cart",{Cid:1234})}>
      <Icon style={{marginTop:25,color:"white",marginLeft:130}} name="ios-cart" color="white"/>
</TouchableOpacity>
      <Text style={{position:"relative",color:"#1cd4ee",fontSize:18,marginLeft:-15,marginTop:10,fontWeight:"bold",backgroundColor:"orange",height:21,width:21,textAlign:"center",borderRadius:100}}>{this.state.catNo}</Text>
      
          <Item style={{width:"100%",marginTop:70,justifyContent:"center",marginLeft:-335}}>
            <Input style={{width:"100%"}}
            onTouchStart={()=>  this.state.navigation.navigate("Search")}
              placeholder="Search"
              onChangeText={text => this.setState({search:text})}
            />
          <TouchableOpacity  onPress={() => this.state.navigation.navigate("Search")}>
            <Icon style={{color:"#42f9e2"}} name="ios-search"/>
            </TouchableOpacity>
          </Item>
          
        </Header>
    <ScrollView>
      <View style={styles.containeri}>
        <SwiperFlatList
          autoplay
          autoplayDelay={2}
          autoplayLoop
          index={2}
          showPagination
        >
          <View style={[styles.childi, { backgroundColor: 'tomato' }]}>
            <TouchableOpacity>
              <Image style={styles.Thumbnaili} source={{uri:"https://cdn1.vectorstock.com/i/1000x1000/65/60/sale-discount-voucher-template-design-poster-vector-17416560.jpg"}}/>
              </TouchableOpacity>
                        </View>
          <View style={[styles.childi, { backgroundColor: 'thistle' }]}>
            <TouchableOpacity>
              <Image style={styles.Thumbnaili} source={{uri:"https://cdn4.vectorstock.com/i/1000x1000/93/23/creative-sale-banner-in-purple-and-yellow-color-vector-14299323.jpg"}}/>
              </TouchableOpacity>
          </View>
          <View style={[styles.childi, { backgroundColor: 'skyblue' }]}>
            <TouchableOpacity>
              <Image style={styles.Thumbnaili} source={{uri:"https://cdn1.vectorstock.com/i/1000x1000/34/50/discount-voucher-poster-template-design-in-vector-19833450.jpg"}}/>
              </TouchableOpacity>
          </View>
          <View style={[styles.childi, { backgroundColor: 'teal' }]}>
            <TouchableOpacity>
              <Image style={styles.Thumbnaili} source={{uri:"https://cdn3.vectorstock.com/i/1000x1000/65/62/discount-voucher-poster-template-background-vector-17416562.jpg"}}/>
              </TouchableOpacity>
          </View>
        </SwiperFlatList>
      </View>

    <View>
        <View style={styles.MainContaineri}>
        <LinearGradient colors={[this.state.colors[0].name1,this.state.colors[0].name2]}>
        <View style={{height:50}}>
         <Text style={{fontSize:20,color:this.state.title,fontWeight:"bold",marginLeft:10}}>Regular Products</Text>
         <Text style={{fontSize:14,color:"green",marginLeft:10}}>Get Best offer</Text>
        </View>
        <FlatList
          data={this.state.Data}
          renderItem={({ item }) => (
            <View style={{ flex: 1, flexDirection: 'column', margin: 1,height:210,backgroundColor:"white",justifyContent:"center",alignItems:"center",borderRadius:10 }}>
            <TouchableOpacity onPress={() => this.state.navigation.navigate(item.type,{Pid:item.catId,Cat:item.title})}>
              <Image style={styles.imageThumbnaili} source={{uri: item.image}}/>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => this.state.navigation.navigate(item.type,{Pid:item.catId,Cat:item.title})}>
              <Text style={{justifyContent:"center",textAlign:"center",marginTop:0}}>{item.title}</Text>
              </TouchableOpacity>
            </View>
          )}
          //Setting the number of column
          numColumns={2}
        />
        </LinearGradient>
      </View>
      <View style={styles.MainContaineri,{backgroundColor:"#cdec0e"}}>
      <LinearGradient colors={[this.state.colors[1].name1,this.state.colors[1].name2]}>
        <View style={{height:50}}>
         <Text style={{fontSize:20,color:this.state.title,fontWeight:"bold",marginLeft:10}}>Man dress</Text>
         <Text style={{fontSize:14,color:"green",marginLeft:10}}>Get Best offer</Text>
        </View>
        <FlatList
          data={this.state.Vdata}
          renderItem={({ item }) => (
            <View style={{ flex: 1, flexDirection: 'column', margin: 1,height:210,backgroundColor:"white",justifyContent:"center",alignItems:"center",borderRadius:10 }}>
            <TouchableOpacity onPress={() => this.state.navigation.navigate(item.type,{Pid:item.catId,Cat:item.title})}>
              <Image style={styles.imageThumbnaili} source={{uri: item.image}}/>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => this.state.navigation.navigate(item.type,{Pid:item.catId,Cat:item.title})}>
              <Text style={{justifyContent:"center",textAlign:"center",marginTop:0}}>{item.title}</Text>
              </TouchableOpacity>
            </View>
          )}
          //Setting the number of column
          numColumns={2}
        />
        </LinearGradient>
      </View>
      <View style={styles.MainContaineri,{backgroundColor:"#cdec0e"}}>
      <LinearGradient colors={[this.state.colors[2].name1,this.state.colors[2].name2]}>
        <View style={{height:50}}>
         <Text style={{fontSize:20,color:this.state.title,fontWeight:"bold",marginLeft:10}}>Shoes</Text>
         <Text style={{fontSize:14,color:"green",marginLeft:10}}>Get Best offer</Text>
        </View>
        <FlatList
          data={this.state.Vdatax}
          renderItem={({ item }) => (
            <View style={{ flex: 1, flexDirection: 'column', margin: 1,height:210,backgroundColor:"white",justifyContent:"center",alignItems:"center",borderRadius:10 }}>
            <TouchableOpacity onPress={() => this.state.navigation.navigate(item.type,{Pid:item.catId,Cat:item.title})}>
              <Image style={styles.imageThumbnaili} source={{uri: item.image}}/>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => this.state.navigation.navigate(item.type,{Pid:item.catId,Cat:item.title})}>
              <Text style={{justifyContent:"center",textAlign:"center",marginTop:0}}>{item.title}</Text>
              </TouchableOpacity>
            </View>
          )}
          //Setting the number of column
          numColumns={2}
        />
        </LinearGradient>
      </View>

      <View style={{backgroundColor:"transparent"}}>
      <LinearGradient colors={[this.state.colors[3].name1,this.state.colors[3].name2]}>
      <View style={{height:50}}>
         <Text style={{fontSize:20,color:this.state.title,fontWeight:"bold",marginLeft:10}}>Man dress</Text>
         <Text style={{fontSize:14,color:"green",marginLeft:10}}>Get Best offer</Text>
        </View>
<ScrollView
horizontal={true}
>
        <View style={styles.MainContaineri,{backgroundColor:"transparent"}}>
        <FlatList
          data={videosxx}
          renderItem={({ item }) => (
            <View style={{ flex: 1, flexDirection: 'column', margin: 1,height:220,backgroundColor:"white",alignItems:"center",padding:5}}>
            <TouchableOpacity onPress={() => this.state.navigation.navigate("productView",{Pid:item.pId,Fimage:item.Fimage,Cat:item.catId})}>
              <Image style={styles.imageThumbnaili} source={{uri: item.Fimage}}/>
              <Icon style={{color:"gray",marginLeft:110,position:"absolute",borderRadius:100,width:30,height:30,backgroundColor:"white",paddingLeft:3,paddingRight:1,paddingTop:2,paddingBottom:2,bottom:5}} name="ios-cart" color="white"/>
              </TouchableOpacity>
              <Text style={{marginLeft:-70}}>{item.title}</Text>
              <Text style={{marginLeft:-30}}>{item.shopName}</Text>
              <Text style={{marginLeft:-30,fontSize:15}}>₹999 <Text style={{color:"gray",fontSize:12,textDecorationLine: 'line-through'}}>1999</Text><Text style={{color:"green",fontSize:12}}>  50% off</Text></Text>
            </View>
          )}
          //Setting the number of column
          numColumns={300}
        />
        
      </View>
</ScrollView>
</LinearGradient>
</View>
      
      
      <View style={{backgroundColor:"transparent"}}>
      <LinearGradient colors={[this.state.colors[4].name1,this.state.colors[4].name2]}>
      <View style={{height:50}}>
         <Text style={{fontSize:20,color:this.state.title,fontWeight:"bold",marginLeft:10}}>Best of the day</Text>
         <Text style={{fontSize:14,color:"green",marginLeft:10}}>Get Best offer</Text>
        </View>
<ScrollView
horizontal={true}
>
        <View style={styles.MainContaineri,{backgroundColor:"transparent"}}>
        <FlatList
          data={videosxx1}
          renderItem={({ item }) => (
            <View style={{ flex: 1, flexDirection: 'column', margin: 1,height:220,backgroundColor:"white",alignItems:"center",padding:5}}>
            <TouchableOpacity onPress={() => this.state.navigation.navigate("productView",{Pid:item.pId,Fimage:item.Fimage,Cat:item.catId})}>
              <Image style={styles.imageThumbnaili} source={{uri: item.Fimage}}/>
              <Icon style={{color:"gray",marginLeft:110,position:"absolute",borderRadius:100,width:30,height:30,backgroundColor:"white",paddingLeft:3,paddingRight:1,paddingTop:2,paddingBottom:2,bottom:5}} name="ios-cart" color="white"/>
              </TouchableOpacity>
              <Text style={{marginLeft:-70}}>{item.title}</Text>
              <Text style={{marginLeft:-30}}>{item.shopName}</Text>
              <Text style={{marginLeft:-30,fontSize:15}}>₹999 <Text style={{color:"gray",fontSize:12,textDecorationLine: 'line-through'}}>1999</Text><Text style={{color:"green",fontSize:12}}>  50% off</Text></Text>
            </View>
          )}
          //Setting the number of column
          numColumns={200}
        />
        
      </View>
</ScrollView>
</LinearGradient>
</View>


      <View style={{backgroundColor:"transparent"}}>
      <LinearGradient colors={[this.state.colors[5].name1,this.state.colors[5].name2]}>
      <View style={{height:50}}>
         <Text style={{fontSize:20,color:this.state.title,fontWeight:"bold",marginLeft:10}}>Fast Food</Text>
         <Text style={{fontSize:14,color:"green",marginLeft:10}}>Get Best offer</Text>
        </View>
<ScrollView
horizontal={true}
>
        <View style={styles.MainContaineri,{backgroundColor:"transparent"}}>
        <FlatList
          data={videosxx2}
          renderItem={({ item }) => (
            <View style={{ flex: 1, flexDirection: 'column', margin: 1,height:220,backgroundColor:"white",alignItems:"center",padding:5}}>
            <TouchableOpacity onPress={() => this.state.navigation.navigate("productView",{Pid:item.pId,Fimage:item.Fimage,Cat:item.catId})}>
              <Image style={styles.imageThumbnaili} source={{uri: item.Fimage}}/>
              <Icon style={{color:"gray",marginLeft:110,position:"absolute",borderRadius:100,width:30,height:30,backgroundColor:"white",paddingLeft:3,paddingRight:1,paddingTop:2,paddingBottom:2,bottom:5}} name="ios-cart" color="white"/>
              </TouchableOpacity>
              <Text style={{marginLeft:-70}}>{item.title}</Text>
              <Text style={{marginLeft:-30}}>{item.shopName}</Text>
              <Text style={{marginLeft:-30,fontSize:15}}>₹999 <Text style={{color:"gray",fontSize:12,textDecorationLine: 'line-through'}}>1999</Text><Text style={{color:"green",fontSize:12}}>  50% off</Text></Text>
            </View>
          )}
          //Setting the number of column
          numColumns={20}
        />
        
      </View>
</ScrollView>
</LinearGradient>
</View>

        <View>
           <LinearGradient colors={[this.state.colors[6].name1,this.state.colors[6].name2]}>
        <View style={styles.MainContaineri,{backgroundColor:"transparent",marginTop:10}}>
        <View style={{height:50}}>
         <Text style={{fontSize:20,color:this.state.title,fontWeight:"bold",marginLeft:10}}>Fast Food</Text>
         <Text style={{fontSize:14,color:"green",marginLeft:10}}>Get Best offer</Text>
        </View>

        <FlatList
          data={this.state.Vdataxx3}
          renderItem={({ item }) => <Itemx item={item} navigation={this.state.navigation}/>}
        
          numColumns={2}
        />
        
      </View>
      </LinearGradient>
       </View>
    </View>
            </ScrollView>
        {this.state.lode==0?
       <View style={{backgroundColor: 'rgba(255, 255, 255, 0.8)',justifyContent:"center",position:"absolute",alignItems:"center",textAlign:"center",alignSelf:"center",height:"100%",width:"100%",flex:0}}>
        <Image
          style={styles.stretch}
          source={{uri:'https://i.stack.imgur.com/kOnzy.gif'}}
        />
      </View>:null}
            {this.state.Status == 0?
            <TouchableOpacity activeOpacity={0.5} onPress={this.SampleFunction} style={styles.TouchableOpacityStyle} >

          <Image source={{uri : 'https://mandawamart.com/admin/map.png'}} 
          
                 style={styles.FloatingButtonStyle} />
       
        </TouchableOpacity>:null}
        </SafeAreaView>
    );
  }
}

export default DisplayAnImageWithStyle;
