import React from 'react';
import { StyleSheet, Text, View, FlatList, Image, TouchableOpacity } from 'react-native';
import {
  Container,
    Header,
  Content,
  Left,
  Right,
  Body,
  Icon,
  ListItem,
  Thumbnail,
  Input,
  Footer,
} from 'native-base';
import styles from "./styles"
import firebase from '../pages/firebase.js';
import AsyncStorage from '@react-native-community/async-storage';
const db = firebase.firestore();
function Item({ item,navigation}) {
  return (
    <View style={styles.listItem}>
    <TouchableOpacity onPress={() => /*navigation.navigate("Conform Your Order",{Price:item.price,Image:item.image,Km:item.km})*/ alert("Call for Rent\n9649215382")}>
      <Image style={{width:110, height:120}} source={{uri: item.image}}/>
      </TouchableOpacity>
      <View style={{flex:1,marginLeft:10}}>
      <TouchableOpacity>
        <Text style={{fontWeight:"bold",fontSize:18}}>{item.title}</Text>
        <Text style={{color:"gray",fontSize:16}}>{item.number}</Text>
        <Text style={{fontSize:16}}>{item.km}Km / ₹{item.price}</Text>
        <Text style={{color:"gray"}}>Petrol and Diesel is your</Text>
        <Text style={{color:"#069609"}}>Get at your location</Text>
       </TouchableOpacity>     
      </View>
      <TouchableOpacity style={{height:50,width:50, justifyContent:"center",alignItems:"center"}} onPress={() => /*navigation.navigate("Conform Your Order",{Price:item.price,Image:item.image,Km:item.km})*/ alert("Call for Rent\n9649215382")}>
                      <Icon style={{color:"gray",borderRadius:100,width:30,height:30,backgroundColor:"white"}} name="arrow-forward"/>
      </TouchableOpacity>
    </View>
  );
}
const Lproduct=[];
const cat="Vehicles On Rent";
export default class App extends React.Component {
   constructor({route,navigation}){
   super();
    this.state = {
      navigation:navigation,
      Data:[],
      Status:1,
      Uid:"",
    };             

  }
    componentDidMount() {
this.getData();
    db.collection('track')
               .where('Uid', '==',this.state.Uid)
               .where('Status', '==',0)
               .get()
               .then(querySnapshot => {
                  querySnapshot.forEach(documentSnapshot => {
                        if (documentSnapshot.data().Status==0) {
                          this.setState({Status:0})
                        }else
                        {
                          this.setState({Status:1})
                        }
                            });
                });
      var len=Lproduct.length;
      var i=0;
      while(len>=i){
        Lproduct.pop();
        i=i+1;
      }
      this.fatch();
    }
      fatch=()=>{
                db.collection('Bick')
                .where('Status', '==',1)
                .get()
                .then(querySnapshot => {
                  querySnapshot.forEach(documentSnapshot => {
                        Lproduct.push(documentSnapshot.data());
                        this.setState({Data:Lproduct})
                        console.log(Lproduct);
                            });
                });

                }
               SampleFunction=()=>{

      this.state.navigation.navigate("Order");

  }
  getData = async () => {
  AsyncStorage.getItem('@uid').then(
      (value) =>{
        // AsyncStorage returns a promise
        // Adding a callback to get the value
        this.setState({Uid:value})
        if (value) {}
        else{
          this.state.navigation.navigate("Login")
      }
    }
      // Setting the value in Text
    );
}
  render(){
    return (
      <View style={styles.container}>
      <Header style={{backgroundColor:'#1cd4ee',height:60}} searchBar rounded>
      <TouchableOpacity onPress={() => this.state.navigation.goBack()}>
      <Icon style={{marginTop:17,color:"white",marginLeft:-10,marginRight:10}} name="ios-arrow-back" color="white"/>
      </TouchableOpacity>
      <Image style={styles.Logo} source={{uri:"https://images.financialexpress.com/2019/04/car-660.jpg"}}/>
      <Text style={{position:"relative",color:"white",fontSize:18,marginLeft:10,marginTop:17,width:150}}>{cat.slice(0, 14)+".."}</Text>
      <TouchableOpacity onPress={() => this.state.navigation.navigate("Search")}>
      <Icon style={{marginTop:17,color:"white",marginLeft:10}} name="ios-search" color="white"/>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => this.state.navigation.navigate("Cart",{Cid:1234})}>
      <Icon style={{marginTop:17,color:"white",marginLeft:30}} name="ios-cart" color="white"/>
      </TouchableOpacity>
      <Text style={{position:"relative",color:"red",fontSize:20,marginLeft:-17,marginTop:5,fontWeight:"bold",width:20,height:22,borderRadius:100,paddingLeft:5}}>5</Text>
        </Header>
        <FlatList
          style={{flex:1}}
          data={this.state.Data}
          renderItem={({ item }) => <Item item={item} navigation={this.state.navigation}/>}
        />
        {this.state.Status == 0?
            <TouchableOpacity activeOpacity={0.5} onPress={this.SampleFunction} style={styles.TouchableOpacityStyle} >

          <Image source={{uri : 'https://mandawamart.com/admin/map.png'}} 
          
                 style={styles.FloatingButtonStyle} />
       
        </TouchableOpacity>:null}
      </View>
    );
  }
}
