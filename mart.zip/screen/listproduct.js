import React from 'react';
import { StyleSheet, Text, View, FlatList, Image, TouchableOpacity } from 'react-native';
import {
  Container,
    Header,
  Content,
  Left,
  Right,
  Body,
  Icon,
  ListItem,
  Thumbnail,
  Input,
  Footer,
} from 'native-base';
import styles from "./styles"
import Head from './head.js';
import firebase from '../pages/firebase.js';
import AsyncStorage from '@react-native-community/async-storage';
const db = firebase.firestore();
function Item({ item,navigation,that,index}) {
  return (
    <View style={styles.listItem}>
    <TouchableOpacity onPress={() => navigation.navigate("productView",{Pid:item.pId,Fimage:item.Fimage,Cat:item.catId})}>
      <Image style={{width:110, height:120}} source={{uri: item.Fimage}}/>
      </TouchableOpacity>
      <View style={{flex:1,marginLeft:10}}>
      <TouchableOpacity onPress={() => navigation.navigate("productView",{Pid:item.pId,Fimage:item.Fimage,Cat:item.catId})}>
        <Text style={{fontWeight:"bold"}}>{item.title}</Text>
        <Text style={{color:"gray"}}>{item.shopName}</Text>
        <Text style={{color:"white",backgroundColor:"#138f32",padding:2,width:40}}>4.5 ★ </Text><Text style={{color:"gray"}}>(<Icon style={{color:"gray",fontSize:16}} name="ios-person"/> 250)</Text>
        <Text style={{fontSize:16}}>₹{item.newPrice} <Text style={{color:"gray",fontSize:12,textDecorationLine: 'line-through'}}>{item.oldPrice}</Text><Text style={{color:"green",fontSize:12}}>  50% off</Text></Text>
       </TouchableOpacity>     
      </View>
      {item.Qty==0?
      <TouchableOpacity style={{height:50,width:50, justifyContent:"center",alignItems:"center"}} onPress={()=>that.Add(item.title,item.pId,item.Fimage,item.newPrice,item.oldPrice,item.qty,item.shopName,index)}>
                      <Icon style={{color:"gray",borderRadius:100,width:30,height:30,backgroundColor:"white"}} name="ios-cart"/>
      </TouchableOpacity>:<TouchableOpacity style={{height:50,width:50, justifyContent:"center",alignItems:"center"}} onPress={()=> alert("Product Allready Added")}>
                      <Icon style={{color:"#1cd4ee",borderRadius:100,width:30,height:30,backgroundColor:"white"}} name="ios-cart"/>
      </TouchableOpacity>}
    </View>
  );
}
const Lproduct=[];
export default class App extends React.Component {
   constructor({route,navigation}){
      const {Pid,Cat} =route.params;
   super();
    this.state = {
      navigation:navigation,
      catId:Pid,
      Data:[],
      Status:1,
      Uid:"",
      lode:0,
      this:this,
      Cat:Cat,
      List:[],
    };             

  }
    componentDidMount() {
      this.getData();
      var len=Lproduct.length;
      var i=0;
      while(len>=i){
        Lproduct.pop();
        i=i+1;
      }
      this.fatch();
          db.collection('track')
               .where('Uid', '==',this.state.Uid)
               .where('Status', '==',0)
               .get()
               .then(querySnapshot => {
                  querySnapshot.forEach(documentSnapshot => {
                        if (documentSnapshot.data().Status==0) {
                          this.setState({Status:0})
                        }else
                        {
                          this.setState({Status:1})
                        }
                            });
                });
    }
     getData = async () => {
  AsyncStorage.getItem('@uid').then(
      (value) =>{
        // AsyncStorage returns a promises
        // Adding a callback to get the value
        this.setState({Uid:value})
    }
      // Setting the value in Text
    );
}
      fatch=()=>{
                db.collection('Product')
                .where('catId','==',this.state.catId)
                .get()
                .then(querySnapshot => {
                  querySnapshot.forEach(documentSnapshot => {
                        Lproduct.push(documentSnapshot.data());
                        this.setState({Data:Lproduct,lode:1,List:Lproduct})
                            });
                });

                }
               SampleFunction=()=>{

      this.state.navigation.navigate("Order");

  }
Add=(a,b,c,d,e,f,g,x)=> {
  var tx=this.state.Data;
  tx[x].Qty=1;
  this.setState({List:tx});
  db
  .collection('cart')
  .add({
    pId:b,
    size:"",
    ip:"",
    uid:this.state.Uid,
    title:a,
    Nprice:d,
    Oprice:e,
    Qty:1,
    image:c,
    seller:g,
  })
 .then(docRef => {}) 
}
  render(){
    return (
      <View style={styles.container}>
      <Head Cat={this.state.Cat} navigation={this.state.navigation}/>
        <FlatList
          style={{flex:1}}
          data={this.state.List}
          renderItem={({ item,index }) => <Item item={item} navigation={this.state.navigation} that={this.state.this} index={index}/>}
        />

        {this.state.lode==0?
       <View style={{backgroundColor: 'rgba(255, 255, 255, 0.8)',justifyContent:"center",position:"absolute",alignItems:"center",textAlign:"center",alignSelf:"center",height:"100%",width:"100%",flex:0}}>
        <Image
          style={styles.stretch}
          source={{uri:'https://i.stack.imgur.com/kOnzy.gif'}}
        />
      </View>:null}
        {this.state.Status == 0?
            <TouchableOpacity activeOpacity={0.5} onPress={this.SampleFunction} style={styles.TouchableOpacityStyle} >

          <Image source={{uri : 'https://mandawamart.com/admin/map.png'}} 
          
                 style={styles.FloatingButtonStyle} />
       
        </TouchableOpacity>:null}
      </View>
    );
  }
}