import React, { Component } from 'react';
import { Container, Header, Tab, Tabs, ScrollableTab } from 'native-base';
import Tab1 from './screen/Tab.js';

export default class TabsScrollableExample extends Component {
  render() {
    return (
      <Container>
        <Tabs transparent  renderTabBar={()=> <ScrollableTab style={{ backgroundColor: "#ccc" }}/>}>
          <Tab style={{borderWidth:1,backgroundColor: 'red'}} heading="Tab1">
            <Tab1 cat={0} />
          </Tab>
          <Tab style={{borderWidth:1,backgroundColor: 'red'}} heading="Tab1">
            <Tab1 cat={1}/>
          </Tab>
          <Tab heading="Tab1">
            <Tab1 cat={2} />
          </Tab>
          <Tab heading="Tab1">
            <Tab1 cat={3}/>
          </Tab>
          <Tab heading="Tab1">
            <Tab1 cat={4}/>
          </Tab>
        </Tabs>
      </Container>
    );
  }
}