import React, { Component } from "react";
import {
  Alert,
  Modal,
  StyleSheet,
  Text,
  TouchableHighlight,
  View,ScrollView,FlatList, TouchableOpacity
} from "react-native";
import {
  Container,
  Header,
  Content,
  Left,
  Right,
  Body,
  Icon,
  ListItem,
  Thumbnail,
  Input,
  Footer,
} from 'native-base';
import AsyncStorage from '@react-native-community/async-storage';
import firebase from '../pages/firebase.js';
const db = firebase.firestore();
function Item({ item,navigation}) {
  return (
    <View style={{width:"100%"}}>
      <TouchableOpacity onPress={() => navigation.navigate("Insert",{Catid:item.catId,Pid:1234})}>         
              <Text style={{marginBottom: 15,textAlign: "center",fontSize:18,shadowColor: "#000",
    shadowOffset: {
      width: 2,
      height: 20
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,backgroundColor:"#ebebeb80",padding:5,width:300,borderRadius:10,paddingTop:20,paddingBottom:20
     }}>{item.title}</Text>
      </TouchableOpacity>
    </View>

    );
  }

const videos=[];
class App extends Component {
  constructor({route,navigation}){
    console.disableYellowBox = true;
   super();
    this.state = {
      navigation:navigation,
      modalVisible: false,
      Uid:"",
      catData:[],
      catId:[],
      
    };
    this.getData();

  }
  componentDidMount(){
        db.collection('cat')
                .get()
                .then(querySnapshot => {
                  querySnapshot.forEach(documentSnapshot => {
                  videos.push(documentSnapshot.data());

                  var title=documentSnapshot.data().title;
                  this.state.catData.push(title);
                  this.state.catId.push(documentSnapshot.data().catId);
                });
                });
  }
  setModalVisible = (visible) => {
    this.setState({ modalVisible: visible });
  }

  CatidData = (visible,catId,Pid) => {
    this.setState({ modalVisible: visible });
    this.state.navigation.navigate("Insert",{Catid:catId,from:"cat",Pid:Pid});
  }
  getData = async () => {
  AsyncStorage.getItem('@Amobile').then(
      (value) =>{
        // AsyncStorage returns a promise
        // Adding a callback to get the value
        AsyncStorage.getItem('@uid').then(
          (valuex) =>{this.setState({Uid:valuex})})
        if (value==9649215382) {
        }
        else{
          this.state.navigation.navigate("FirstPage")
      }
    }
      // Setting the value in Text
    );
}
  render() {
    const { modalVisible } = this.state;
    return (
      <View style={styles.centeredView}>
        <Modal
          animationType="slide"
          transparent={true}
          visible={modalVisible}
          onRequestClose={() => {
            Alert.alert("Modal has been closed.");
          }}
        >
          <View style={styles.modalView}>
          <View style={{flexDirection:"row",}}>
          <Text style={{fontSize:19}}>
          Select Product Category
          </Text>
          <TouchableHighlight
          style={{backgroundColor:"white"}}
                onPress={() => {
                  this.setModalVisible(!modalVisible);
                }}
              >
          <Icon style={{color:"black",marginLeft:40,fontSize:36,marginTop:-3}} name="ios-close"/>
          </TouchableHighlight>
          </View>
          <ScrollView>
            <View style={styles.modalViewx}>
            <FlatList
          style={{flex:1}}
          data={videos}
          renderItem={({ item }) => (
          <View style={{width:"100%"}}>
          <TouchableOpacity onPress={() => {
                  this.CatidData(!modalVisible,item.catId,1234);
                }}>         
          <Text style={{marginBottom: 15,textAlign: "center",fontSize:18,shadowColor: "#000",
            shadowOffset: {
              width: 2,
              height: 20
            },
            shadowOpacity: 0.25,
            shadowRadius: 3.84,
            elevation: 5,backgroundColor:"#ebebeb80",padding:5,width:300,borderRadius:10,paddingTop:20,paddingBottom:20
             }}>{item.title}</Text>
          </TouchableOpacity>
        
    </View>
   )}
   numColumns={1}
          keyExtractor={item => item.catId}
        />
              
      </View>
       </ScrollView>     
          </View>
        </Modal>
   <View style={{flexDirection:"row"}}>
        <TouchableOpacity
          style={styles.openButton}
          onPress={() => {
            this.setModalVisible(true);
          }}
        >
          <Text style={styles.textStyle}><Text style={{fontWeight:"bold"}}>+</Text> Add Product</Text>
        </TouchableOpacity>
        <View style={{height:10,padding:12}}
        ></View>
        <TouchableOpacity
          style={styles.openButton}
          onPress={() => {this.state.navigation.navigate("VProduct",{CatData:this.state.catData,catId:this.state.catId})}}
        >
          <Text style={styles.textStyle}><Text style={{fontSize:16}}> Products</Text></Text>
        </TouchableOpacity>
      </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 22
  },
  modalView: {
    margin: 10,
    backgroundColor: "white",
    borderRadius: 10,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5
  },
  modalViewx: {
    margin: 10,
    backgroundColor: "white",
    borderRadius: 10,
    width:300,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5
  },
  openButton: {
    backgroundColor: "#F194FF",
    borderRadius: 20,
    padding: 10,
    elevation: 2
  },
  textStyle: {
    color: "white",
    fontWeight: "bold",
    textAlign: "center"
  },
  modalText: {
    marginBottom: 15,
    textAlign: "center"
  }
});

export default App;