import Constants from 'expo-constants';
import * as Notifications from 'expo-notifications';
import React, { Component, useState } from 'react';
import { Image, View, Dimensions, StyleSheet, TouchableOpacity,Modal,Alert,Platform } from 'react-native';
import { Container, Content, Item, Input, Text, Button} from 'native-base';
import firebase from './firebase';
import publicIP from 'react-native-public-ip';

import * as Location from 'expo-location';
import * as Permissions from 'expo-permissions'
import AsyncStorage from '@react-native-community/async-storage';
const db=firebase.firestore();
const {width, height} = Dimensions.get("window");
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: false,
    shouldSetBadge: false,
  }),
});
export default class Login extends Component {
    constructor({route,navigation}) {  
        super();  
        this.state = {text: '',pass: 'dsf',emailWarn:'',passWarn:'',modalVisible: false,OTP:null,token:"",UidError:"no"
        ,uid:"",navigation:navigation,notification:"",otpd1:"",otpd2:"",otpd3:"",otpd4:"",ipAddress:"",latitude:0,longitude:0,
      };
      this._getLocationAsync();
      publicIP()
          .then(ip => {
                  var url = 'http://api.ipstack.com/'+ip+'?access_key=7d2446dd2b89b6bbbe347e21777e6cb5';
          fetch(url)
            .then((response) => response.json())
            .then((responseJson) => {
              this.setState({
              
                ipAddress:responseJson.ip,
              })

            })
            .catch((error) => {
             //console.error(error);
            });
          })
          .catch(error => {
            console.log(error);
            // 'Unable to get IP address.'
          });
    } 
     setModalVisible = (visible) => {
    if (this.state.emailWarn!="yes") {
      if (this.state.text.length==10) {
        var otp=this.getRndInteger(1111,9999);
        this.setState({OTP:otp});
        schedulePushNotification(otp);
      this.setState({ modalVisible: visible });
    }else{
      alert("Invalid Mobile Number");
    }
    }
    else{
     db.collection('user')
        .where('mobile','==',this.state.text)
        .where('Password','==',this.state.pass)
                .get()
                .then(querySnapshotx => {
                  querySnapshotx.forEach(documentSnapshotx => {
                  this.storeData(documentSnapshotx.data().uid);
                  this.state.navigation.navigate("FirstPage");
                            });
                })
    }
  }
 getRndInteger=(min, max)=> {
  return Math.floor(Math.random() * (max - min)) + min;
}

  _getLocationAsync = async () => {
   let { status } = await Permissions.askAsync(Permissions.LOCATION);
   if (status !== 'granted') {
    this._getLocationAsync();
     this.setState({
       locationResult: 'Permission to access location was denied',
     });
   } else {
     this.setState({ hasLocationPermissions: true });
   }

   let location = await Location.getCurrentPositionAsync({
   });
   this.setState({ locationResult: JSON.stringify(location) });
   // Center the map on the location we just fetched.
    this.setState({
      latitude: location.coords.latitude, longitude: location.coords.longitude});
}

 storeData = async (value) => {
  if (value) {
      // To check the input not empty
      AsyncStorage.setItem('@uid', value.toString());
      AsyncStorage.setItem('@Amobile', this.state.text);
      // Setting a data to a AsyncStorage with respect to a key
      // Resetting the TextInput
      // Alert to confirm
    }
}


    fireData=(xx)=>{
    if (this.state.OTP==this.state.OTP) {      
    if (this.state.emailWarn!="yes") {
      this.setState({ modalVisible: false });
      db.collection('user')
      .add({
       mobile:this.state.text,
       latitude:this.state.latitude,
       longitude:this.state.longitude,
       NotificationID:this.state.token,
       Password:this.state.pass,
       uid:xx,
       ip:this.state.ipAddress,
        }).then((x)=>{
          this.storeData(xx);
          this.sendPushNotification("ExponentPushToken[LEU_lkOGxSzrT2Nrd2502D]");
          this.state.navigation.navigate("FirstPage");
        })
    }
    else{
      db.collection('user')
        .where('mobile','==',this.state.text)
                .get()
                .then(querySnapshotx => {
                  querySnapshotx.forEach(documentSnapshotx => {
                  this.sendPushNotification("ExponentPushToken[LEU_lkOGxSzrT2Nrd2502D]");
                  this.storeData(documentSnapshotx.data().uid);
                  this.state.navigation.navigate("FirstPage");
                            });
                })
    }
    }
  }
    componentDidMount() {
       registerForPushNotificationsAsync().then(token => this.setState({token}));
      Notifications.addNotificationReceivedListener(notification => { this.setState({notification})
    });
    }
    find=(text)=>{
      if (text) {
        db.collection('user')
        .where('mobile','==',text.text)
                .get()
                .then(querySnapshotx => {
                  this.setState({text:text.text,emailWarn:"no"})
                  querySnapshotx.forEach(documentSnapshotx => {
                        this.setState({emailWarn:"yes"})
                            });
                })
      }
    }
    sendPushNotification=async(expoPushToken)=> {
  const message = {
    to: expoPushToken,
    sound: 'default',
    title: 'Coagulation   m   Mart get new user',
    body: 'm   Mart get new user',
    data: { data: 'Order' },
  };

  await fetch('https://exp.host/--/api/v2/push/send', {
    method: 'POST',
    headers: {
      Accept: 'application/json',
      'Accept-encoding': 'gzip, deflate',
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(message),
  });
}
  render() {
    const { modalVisible } = this.state;
    return (
    <Container>   
            <Content>
            <View style={styles.centeredView}>
        <Modal
          animationType="slide"
          transparent={true}
          visible={modalVisible}
          onRequestClose={() => {
            Alert.alert("Enter OTP First");
          }}
        >
          <View style={styles.centeredView}>
            <View style={styles.modalView}>
              <Text style={styles.modalText}>Verify the Authorization Code</Text>
              <Text style={{fontSize:18,margin:20}}>Enter OTP</Text>
               <View style={{flexDirection:"row",marginBottom:20}}>
               <Input onChangeText={(otpd1) => this.setState({otpd1})} maxLength={1} keyboardType='number-pad' style={{borderWidth:1,height:50,width:50,textAlign:"center",marginRight:10,borderRadius:6}} value={this.state.notification && JSON.stringify(this.state.notification.request.content.data.OTPd1)}/>
               <Input onChangeText={(otpd2) => this.setState({otpd2})} maxLength={1} keyboardType='number-pad' style={{borderWidth:1,height:50,width:50,textAlign:"center",marginRight:10,borderRadius:6}} value={this.state.notification && JSON.stringify(this.state.notification.request.content.data.OTPd2)}/>
               <Input onChangeText={(otpd3) => this.setState({otpd3})} maxLength={1} keyboardType='number-pad' style={{borderWidth:1,height:50,width:50,textAlign:"center",marginRight:10,borderRadius:6}} value={this.state.notification && JSON.stringify(this.state.notification.request.content.data.OTPd3)}/>
               <Input onChangeText={(otpd4) => this.setState({otpd4})} maxLength={1} keyboardType='number-pad' style={{borderWidth:1,height:50,width:50,textAlign:"center"}} value={this.state.notification && JSON.stringify(this.state.notification.request.content.data.OTPd4)}/>
               </View>
              <TouchableOpacity
                style={{ ...styles.openButton, backgroundColor: "#2196F3" }}
                onPress={() => {
                  this.fireData(this.getRndInteger(111111111111111111111111,999999999999999999999999999999));
                }}
              >
                <Text style={styles.textStyle}>Submit</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      </View>
                <View>
                    <View style={{flexDirection:'row',backgroundColor:"#1cd4ee",marginTop:-23}}>
                        <View style={{height:(height/3)+30,justifyContent:'center'}}>
                        <Text style={styles.title}>
                          M-Mart
                        </Text>
                        </View>
                    </View>
                    <Image source={require('../assets/wave.png')} style={{width:width,height:(height/9)+5.9, resizeMode:'stretch', marginTop:0}}/>
                    <View style={{alignItems:'center',height:500}}>
                        <View style={styles.LoginBox}>
                            <Item style={{marginTop:30}}>
                                <Image style={{width:25,height:25}} source={require('../assets/emailicon.png')}/>
                                <Input keyboardType='number-pad' placeholder='  Mobile No'
                                onChangeText={(text) => this.find({text})} />
                            </Item>

                            <Item style={{marginTop:5}}>
                                <Image source={require('../assets/keyicon.png')}/>
                                <Input secureTextEntry={true} maxLength={8} placeholder=' New Password'
                                onChangeText={(pass) => this.setState({pass})}
                                />
                            </Item>
                            <Text style={{color:'red'}}>{this.state.passWarn}</Text>

                            <Button block info  style={{marginTop:5}} onPress={() => {
                  this.setModalVisible(true);
                }}>
                                <Text>LOGIN</Text>
                            </Button>

                        </View>
                    </View>
                </View>
            </Content>
      </Container>
    );
  }
}

const styles = StyleSheet.create({
    title:{
      fontSize:52,
      padding:15,
      color:'white',
    },
    LoginBox:{
      height:height/2,
      width: width-40,
      backgroundColor: '#fff',
      borderRadius:15,
      marginTop:-150,
      shadowRadius:0.5,
      shadowColor:'#000',
      shadowOffset:{width:0.5,height:0.5},
      shadowOpacity:0.5,
      elevation:5,
      padding:15,
    },
    centeredView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 22,
    width:"100%"
  },
  modalView: {
    margin: 20,
    width:"100%",
    height:500,
    backgroundColor: "white",
    borderRadius: 20,
    padding: 35,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5
  },
  openButton: {
    backgroundColor: "#F194FF",
    borderRadius: 10,
    padding: 10,
    elevation: 2,
    width:200
  },
  textStyle: {
    color: "white",
    fontWeight: "bold",
    textAlign: "center"
  },
  modalText: {
    marginBottom: 15,
    fontSize:22,
  }
  })
  async function schedulePushNotification(xx) {
    var x=xx.toString();
  await Notifications.scheduleNotificationAsync({
    content: {
      title: "M-Mart Login",
      body: 'Your OTP Code is - '+ x ,
      data: { OTPd1: parseInt(x[0]),OTPd2: parseInt(x[1]),OTPd3:parseInt(x[2]),OTPd4: parseInt(x[3]) },
    },
    trigger: { seconds: 2 },
  });
}

async function registerForPushNotificationsAsync() {
  let token;
  if (Constants.isDevice) {
    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;
    if (existingStatus !== 'granted') {
      this.registerForPushNotificationsAsync();
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }

    if (finalStatus !== 'granted') {
      this.registerForPushNotificationsAsync();
      alert('Failed to get push token for push notification!');
      return;
    }
     token = (await Notifications.getExpoPushTokenAsync()).data;
  } else {
    this.registerForPushNotificationsAsync();
    alert('Must use physical device for Push Notifications');
  }

  if (Platform.OS === 'android') {
    Notifications.setNotificationChannelAsync('default', {
      name: 'default',
      importance: Notifications.AndroidImportance.MAX,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: '#FF231F7C',
    });
  }

  return token;
}
