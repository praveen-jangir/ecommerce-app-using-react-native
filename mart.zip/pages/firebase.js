import firebase from 'firebase';
firebase.initializeApp(firebaseConfig = {
apiKey: "AIzaSyAgpJc6AJD7GXwToaIppxVQStAVAABjKvU",
    authDomain: "dukan-cb08d.firebaseapp.com",
    projectId: "dukan-cb08d",
    storageBucket: "dukan-cb08d.appspot.com",
    messagingSenderId: "686672543256",
    appId: "1:686672543256:web:c44ec4666b197987974d6d",
    measurementId: "G-W78H78X5SV"
    /*apiKey: "AIzaSyDkVxJn9Fv8xkUhQdEeboBcf9fs1yLtLzM",
    authDomain: "dukanx-f1127.firebaseapp.com",
    projectId: "dukanx-f1127",
    storageBucket: "dukanx-f1127.appspot.com",
    messagingSenderId: "377801732898",
    appId: "1:377801732898:web:7ca3eb264500ad8fe42b7b",
    measurementId: "G-HBRCPKBVTY"*/
  });
  // Initialize Firebase
  
  export default firebase;