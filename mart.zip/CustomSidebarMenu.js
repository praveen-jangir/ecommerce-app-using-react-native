// Custom Navigation Drawer / Sidebar with Image and Icon in Menu Options
// https://aboutreact.com/custom-navigation-drawer-sidebar-with-image-and-icon-in-menu-options/

import React from 'react';
import {
  SafeAreaView,
  View,
  StyleSheet,
  Image,
  Text,
  Linking,
} from 'react-native';
import {
  Container,
    Header,
  Content,
  Left,
  Right,
  Body,
  Icon,
  ListItem,
  Thumbnail,
  Input,
  Footer,
} from 'native-base';
import {
  DrawerContentScrollView,
  DrawerItemList,
  DrawerItem,
} from '@react-navigation/drawer';

const CustomSidebarMenu = (props) => {

  return (
    <SafeAreaView style={{ flex: 1 }}>
      {/*Top Large Image */}
      <Image
        source={require('./assets/splash.png')}
        style={styles.sideMenuProfileIcon}
      />
      <DrawerContentScrollView {...props}>
        <DrawerItemList {...props} />
        <View style={{flexDirection:"row",width:300,borderTopWidth:1,borderColor:"#ccccccbd",}}>
        <Icon style={{padding: 16,
    flexDirection: 'row',
    alignItems: 'center',marginRight:-20,color:"#1cd4ee"}} name="ios-apps" color="white"/>
          <DrawerItem  
          style={{width:300}}  
          label="All Categories"
          onPress={() => props.navigation.navigate("All Catrgories")}
        />
        </View>



<View style={{flexDirection:"row",width:300}}>
        <Icon style={{padding: 16,
    flexDirection: 'row',
    alignItems: 'center',marginRight:-20,color:"#1cd4ee"}} name="ios-call" color="white"/>
        <DrawerItem  
          style={{width:300}}  
          label="Direct Order"
          onPress={() => Linking.openURL(`tel:9649215382`)}
        />

        </View>


        <View style={{flexDirection:"row",width:300}}>
        <Icon style={{padding: 16,
    flexDirection: 'row',
    alignItems: 'center',marginRight:-20,color:"#1cd4ee"}} name="ios-car" color="white"/>
        <DrawerItem  
          style={{width:300}}  
          label="Rent Vehicles"
          onPress={() => props.navigation.navigate("Vehicles On Rent")}
        />

        </View>
        
        <View style={{flexDirection:"row",width:350,borderTopWidth:1,borderColor:"#ccccccbd",}}>
        <Icon style={{padding: 16,
    flexDirection: 'row',
    alignItems: 'center',marginRight:-20,color:"#1cd4ee"}} name="ios-apps" color="white"/>
        <DrawerItem  
          style={{width:300}}  
          label="Sell on Mart"
          onPress={() => props.navigation.navigate("Pinsert")}
        />  
        </View>
        
        <View style={{flexDirection:"row",width:300,borderTopWidth:1,borderColor:"#ccccccbd",}}>
        <Icon style={{padding: 16,
    flexDirection: 'row',
    alignItems: 'center',marginRight:-20,color:"#1cd4ee"}} name="ios-car" color="white"/>
        <DrawerItem  
          style={{width:300}}
          label="My Orders"
          onPress={() => props.navigation.navigate("My Orders")}
        />

        </View>
        
        <View style={{flexDirection:"row",width:300}}>
        <Icon style={{padding: 16,
    flexDirection: 'row',
    alignItems: 'center',marginRight:-20,color:"#1cd4ee"}} name="ios-cart" color="white"/>
        <DrawerItem  
          style={{width:300}}
          label="My Cart"
          onPress={() => props.navigation.navigate("Cart",{Cid:1234})}
        />

        </View>
        
        <View style={{flexDirection:"row",width:300}}>
        <Icon style={{padding: 16,
    flexDirection: 'row',
    alignItems: 'center',marginRight:-20,color:"#1cd4ee"}} name="ios-person" color="white"/>
        <DrawerItem  
          style={{width:300}}
          label="My Account"
          onPress={() => alert("Sorry Your Account not Working.")}
        />

        </View>
        
        <View style={{flexDirection:"row",width:300}}>
        <Icon style={{padding: 16,
    flexDirection: 'row',
    alignItems: 'center',marginRight:-20,color:"#1cd4ee"}} name="ios-apps" color="white"/>
        <DrawerItem  
          style={{width:300}}
          label="My Coupons"
          onPress={() => alert("Coupons are not Available")}
        />

        </View>
                <View style={{flexDirection:"row",width:300}}>
        <Icon style={{padding: 16,
    flexDirection: 'row',
    alignItems: 'center',marginRight:-20,color:"#1cd4ee"}} name="ios-apps" color="white"/>
        <DrawerItem  
          style={{width:300}}
          label="Logout"
          onPress={() => props.navigation.navigate("Logout")}
        />

        </View>
        <View style={{flexDirection:"row",width:300,borderTopWidth:1,borderColor:"#ccccccbd",}}>

        <DrawerItem  
          style={{width:300}}
          label="Notification Preferences"
          onPress={() => Linking.openURL('http://edugyangroup.com/')}
        />

        </View>
        
        <View style={{flexDirection:"row",width:300}}>
        <DrawerItem  
          style={{width:300}}
          label="Help Center"
          onPress={() => Linking.openURL('http://edugyangroup.com/')}
        />

        </View>
        
        <View style={{flexDirection:"row",width:300}}>
        <DrawerItem  
          style={{width:300}}
          label="Privacy Policy"
          onPress={() => Linking.openURL('http://edugyangroup.com/')}
        />

        </View>
        
        <View style={{flexDirection:"row",width:300}}>
        <DrawerItem  
          style={{width:300}}
          label="Legal"
          onPress={() => Linking.openURL('http://edugyangroup.com/')}
        />
        </View>
      </DrawerContentScrollView>
      <Text style={{ fontSize: 16, textAlign: 'center', color: 'grey' }}>
        www.edugyangroup.com
      </Text>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  sideMenuProfileIcon: {
    width: 200,
    height: 70,
    alignSelf: 'center',
    marginTop:20,
    marginBottom:20,
  },
  iconStyle: {
    width: 15,
    height: 15,
    marginHorizontal: 5,
  },
  customItem: {
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
  },
});

export default CustomSidebarMenu;
